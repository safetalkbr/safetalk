import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import bodyParser from "body-parser";
import emailjs from "@emailjs/nodejs";
import admin from "firebase-admin";
import axios from "axios";

// Firebase Admin Initialization
// Note: In a real app, you'd use a service account JSON file.
// For this environment, we'll assume the environment is already authenticated or use placeholder.
if (!admin.apps.length) {
  try {
    admin.initializeApp({
      credential: admin.credential.applicationDefault(),
      projectId: "safetalk-brasil"
    });
  } catch (e) {
    console.error("Firebase Admin Init Error:", e);
  }
}

// EmailJS Configuration
const EMAILJS_SERVICE_ID = process.env.EMAILJS_SERVICE_ID || "service_nl9yxib";
const EMAILJS_TEMPLATE_ID = process.env.EMAILJS_TEMPLATE_ID || "template_raxru0m";
const EMAILJS_PUBLIC_KEY = process.env.EMAILJS_PUBLIC_KEY || "Pf5SdtDfUM8lDfZwG";
const EMAILJS_PRIVATE_KEY = process.env.EMAILJS_PRIVATE_KEY || "";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(bodyParser.json());

  console.log("--- SafeTalk Server Starting ---");
  console.log(`EmailJS Service ID: [${EMAILJS_SERVICE_ID}]`);
  console.log(`EmailJS Template ID: [${EMAILJS_TEMPLATE_ID}]`);
  console.log(`EmailJS Public Key: [${EMAILJS_PUBLIC_KEY ? 'CONFIGURED' : 'MISSING'}]`);
  console.log("--------------------------------");

  // In-memory store for verification codes
  const verificationCodes = new Map<string, { code: string; expires: number }>();

  // Health check route
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // Notification Route
  app.post("/api/send-notification", async (req, res) => {
    const { token, title, body, data } = req.body;
    
    if (!token) {
      return res.status(400).json({ error: "Token is required" });
    }

    try {
      const message = {
        notification: {
          title: title || "Nova Mensagem",
          body: body || "Você recebeu uma nova mensagem no SafeTalk",
        },
        data: data || {},
        token: token,
      };

      const response = await admin.messaging().send(message);
      console.log("[FCM Success]:", response);
      res.json({ success: true, response });
    } catch (err: any) {
      console.error("[FCM Error]:", err);
      res.status(500).json({ error: err.message });
    }
  });

  // API Routes
  app.post("/api/send-code", async (req, res) => {
    const { email } = req.body;
    console.log(`[API] Recebido pedido de código para: ${email}`);
    
    if (!email || !email.includes('@')) {
      return res.status(400).json({ error: "E-mail inválido." });
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    verificationCodes.set(email, { 
      code, 
      expires: Date.now() + 10 * 60 * 1000 // 10 minutes
    });

    console.log(`[EmailJS] Enviando código ${code} para o destinatário dinâmico: ${email}`);

    try {
      const templateParams = {
        user_email: email, // Variável configurada no campo 'To Email' do site EmailJS
        code: code,
      };

      const response = await emailjs.send(
        EMAILJS_SERVICE_ID,
        EMAILJS_TEMPLATE_ID,
        templateParams,
        {
          publicKey: EMAILJS_PUBLIC_KEY,
          privateKey: EMAILJS_PRIVATE_KEY || undefined,
        }
      );

      console.log("[EmailJS Success]:", response);
      res.json({ success: true });
    } catch (err: any) {
      console.error("[EmailJS Error]:", err);
      
      res.status(500).json({ 
        error: "Erro ao enviar e-mail via EmailJS.", 
        details: err
      });
    }
  });

  app.post("/api/verify-code", async (req, res) => {
    const { email, code } = req.body;
    const stored = verificationCodes.get(email);

    if (!stored || stored.code !== code || Date.now() > stored.expires) {
      return res.status(400).json({ error: "Código inválido ou expirado" });
    }

    verificationCodes.delete(email);
    res.json({ success: true });
  });

  // EvoPay Proxy Routes
  app.post("/api/pix/create", async (req, res) => {
    try {
      const response = await axios.post('https://pix.evopay.cash/v1/pix', req.body, {
        headers: {
          'Content-Type': 'application/json',
          'API-Key': '9dbb2062-a7e0-4208-b430-c3f9e10a18a8'
        }
      });
      res.json(response.data);
    } catch (err: any) {
      console.error("[EvoPay Create Error]:", err.response?.data || err.message);
      res.status(err.response?.status || 500).json(err.response?.data || { error: err.message });
    }
  });

  app.get("/api/pix/status", async (req, res) => {
    const { id } = req.query;
    try {
      const response = await axios.get(`https://pix.evopay.cash/v1/pix?id=${id}`, {
        headers: {
          'API-Key': '9dbb2062-a7e0-4208-b430-c3f9e10a18a8'
        }
      });
      res.json(response.data);
    } catch (err: any) {
      console.error("[EvoPay Status Error]:", err.response?.data || err.message);
      res.status(err.response?.status || 500).json(err.response?.data || { error: err.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`--- SafeTalk Server Running ---`);
    console.log(`URL: http://localhost:${PORT}`);
    console.log(`Node Env: ${process.env.NODE_ENV}`);
    console.log(`--------------------------------`);
  });
}

startServer();
