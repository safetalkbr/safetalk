importScripts('https://www.gstatic.com/firebasejs/9.0.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.0.0/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyAutuuEZAp4Bnnw-1oA45Y0U3H3cja_qF0",
  authDomain: "safetalk-brasil.firebaseapp.com",
  projectId: "safetalk-brasil",
  storageBucket: "safetalk-brasil.firebasestorage.app",
  messagingSenderId: "820913360509",
  appId: "1:820913360509:web:0735159c421e8c42fdab14",
  measurementId: "G-QGSZ2XDSCJ"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  
  const type = payload.data?.type;
  const notificationTitle = payload.notification?.title || (type === 'call' ? 'Chamada SafeTalk' : 'SafeTalk');
  const notificationOptions = {
    body: payload.notification?.body || (type === 'call' ? 'Você tem uma nova chamada.' : 'Você recebeu uma nova mensagem.'),
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    data: payload.data,
  };

  if (type === 'call') {
    notificationOptions.actions = [
      { action: 'accept', title: 'Atender' },
      { action: 'decline', title: 'Recusar' }
    ];
    notificationOptions.tag = 'incoming-call';
    notificationOptions.renotify = true;
    notificationOptions.vibrate = [200, 100, 200, 100, 200, 100, 200];
  } else {
    notificationOptions.tag = 'new-message';
  }

  self.registration.showNotification(notificationTitle, notificationOptions);
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const type = event.notification.data?.type;
  
  let url = '/';
  if (type === 'call') {
    if (event.action === 'accept') {
      url = `/?call=incoming&action=accept&callId=${event.notification.data.callId}`;
    } else if (event.action === 'decline') {
      url = `/?call=incoming&action=decline&callId=${event.notification.data.callId}`;
    } else {
      url = `/?call=incoming&callId=${event.notification.data.callId}`;
    }
  } else if (type === 'message') {
    url = `/?chatId=${event.notification.data.chatId}`;
  }

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      // If a window is already open, navigate it to the new URL and focus it
      if (windowClients.length > 0) {
        const client = windowClients[0];
        if ('navigate' in client) {
          client.navigate(url);
        }
        if ('focus' in client) {
          return client.focus();
        }
      }
      // If no window is open, open a new one
      if (clients.openWindow) {
        return clients.openWindow(url);
      }
    })
  );
});
