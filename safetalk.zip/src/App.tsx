/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback, memo } from 'react';
import { 
  onAuthStateChanged,
  User,
  signOut
} from 'firebase/auth';
import { 
  collection, 
  query, 
  orderBy, 
  deleteDoc,
  onSnapshot, 
  addDoc, 
  getDoc,
  serverTimestamp,
  where,
  limit,
  getDocs,
  setDoc,
  doc
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { onMessage } from 'firebase/messaging';
import { auth, db, storage, requestForToken, messaging } from './firebase';
import { generateLogo } from './services/logoService';
import { 
  Phone, 
  MessageSquare, 
  LogOut, 
  PhoneOff, 
  PhoneCall, 
  ShieldCheck, 
  Shield,
  Search, 
  MoreVertical, 
  Camera, 
  Check, 
  CheckCheck, 
  Send, 
  ArrowLeft,
  User as UserIcon,
  Video,
  VideoOff,
  Mail,
  Lock,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  History,
  Settings, 
  UserPlus,
  Plus,
  Trash2,
  Circle,
  Bell,
  HelpCircle,
  Info,
  CameraOff,
  MapPin,
  FileText,
  Image as ImageIcon,
  Play,
  Pause,
  X,
  Paperclip,
  Moon,
  Sun,
  Sparkles,
  Palette,
  Users,
  Bot,
  Wand2,
  Sparkles as SparklesIcon,
  Languages,
  RotateCw,
  CircleDashed,
  Link as LinkIcon,
  ExternalLink,
  Filter,
  RefreshCw,
  ArrowRight,
  ChevronRight,
  Music,
  Ban
} from 'lucide-react';
import Peer from 'simple-peer/simplepeer.min.js';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from 'motion/react';
import toast, { Toaster } from 'react-hot-toast';

// --- Types ---
interface Message {
  id: string;
  text?: string;
  senderId: string;
  timestamp: any;
  type: 'text' | 'audio' | 'image' | 'video' | 'file' | 'location';
  url?: string;
  locationData?: { lat: number; lng: number; address?: string };
  fileName?: string;
  duration?: number;
}

interface Chat {
  id: string;
  name: string;
  lastMessage: string;
  timestamp: any;
  unreadCount?: number;
  avatar?: string;
  themeBackground?: string;
  notificationSound?: string;
  vibrationPattern?: string;
  lastSenderId?: string;
  auraUntil?: number;
  isBusiness?: boolean;
  businessPlan?: any;
  businessVerified?: boolean;
  typing?: any;
  participants?: string[];
}

const NOTIFICATION_SOUNDS = [
  { id: 'default', name: 'Padrão', url: 'https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3' },
  { id: 'bell', name: 'Sino', url: 'https://assets.mixkit.co/active_storage/sfx/2354/2354-preview.mp3' },
  { id: 'pop', name: 'Pop', url: 'https://assets.mixkit.co/active_storage/sfx/2359/2359-preview.mp3' },
  { id: 'crystal', name: 'Cristal', url: 'https://assets.mixkit.co/active_storage/sfx/2360/2360-preview.mp3' },
];

const VIBRATION_PATTERNS = [
  { id: 'default', name: 'Padrão', pattern: [0, 200, 100, 200] },
  { id: 'short', name: 'Curto', pattern: [0, 100] },
  { id: 'long', name: 'Longo', pattern: [0, 500] },
  { id: 'double', name: 'Duplo', pattern: [0, 100, 50, 100] },
  { id: 'none', name: 'Nenhum', pattern: [] },
];

type AuthStep = 'phone' | 'email' | 'email-verify' | 'profile-setup' | 'permissions';
type TabType = 'chats' | 'status' | 'calls';

const formatTime = (seconds: number) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

export default function App() {
  const [user, setUser] = useState<any | null>(null);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setUser(null);
      setView('home');
    } catch (err) {
      console.error('Logout error:', err);
    }
  };
  const [view, setView] = useState<'home' | 'chat'>('home');
  const [activeTab, setActiveTab] = useState<TabType>('chats');
  const [activeChat, setActiveChat] = useState<Chat | null>(null);
  const [chats, setChats] = useState<any[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [statuses, setStatuses] = useState<any[]>([]);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [statusType, setStatusType] = useState<'text' | 'image' | 'video'>('text');
  const [statusText, setStatusText] = useState('');
  const [statusColor, setStatusColor] = useState('#EC6608');
  const [statusImage, setStatusImage] = useState<string | null>(null);
  const [statusVideo, setStatusVideo] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('none');
  const [statusLink, setStatusLink] = useState<string>('');
  const [showStatusOptions, setShowStatusOptions] = useState(false);
  const [viewingStatus, setViewingStatus] = useState<any | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [showContactProfile, setShowContactProfile] = useState(false);
  const [isGeneratingTheme, setIsGeneratingTheme] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isSearchingContact, setIsSearchingContact] = useState(false);
  const [searchPhone, setSearchPhone] = useState('');
  const [groupName, setGroupName] = useState('');
  const [groupParticipants, setGroupParticipants] = useState<string[]>([]);
  const [callHistory, setCallHistory] = useState<any[]>([]);
  const [isAppLoading, setIsAppLoading] = useState(true);
  const [appLogo, setAppLogo] = useState<string | null>(null);
  const [isBiometricEnabled, setIsBiometricEnabled] = useState(false);
  const [isAppLocked, setIsAppLocked] = useState(false);
  const [isBiometricSupported, setIsBiometricSupported] = useState(false);
  const [isVerifyingBiometric, setIsVerifyingBiometric] = useState(false);
  const [currentCallData, setCurrentCallData] = useState<any>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [isRemoteVideoLoading, setIsRemoteVideoLoading] = useState(true);
  const [typingUser, setTypingUser] = useState<string | null>(null);
  const [welcomeMessage, setWelcomeMessage] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  
  // --- Business Account States ---
  const [showBusinessModal, setShowBusinessModal] = useState(false);
  const [showBusinessPlans, setShowBusinessPlans] = useState(false);
  const [selectedBusinessPlan, setSelectedBusinessPlan] = useState<'basic' | 'premium' | 'vip' | null>(null);
  const [showMainMenu, setShowMainMenu] = useState(false);
  const [isAiEnabled, setIsAiEnabled] = useState(false);
  
  // --- Billing & Aura States ---
  const [showBillingModal, setShowBillingModal] = useState(false);
  const [billingAmount, setBillingAmount] = useState<string>('');
  const [pixCode, setPixCode] = useState<string | null>(null);
  const [transactionId, setTransactionId] = useState<string | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<string | null>(null);
  const [isCheckingPayment, setIsCheckingPayment] = useState(false);
  const [paymentType, setPaymentType] = useState<'aura' | 'business'>('aura');
  const [pendingBusinessPlan, setPendingBusinessPlan] = useState<'basic' | 'premium' | 'vip' | null>(null);

  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // --- Billing & Aura Handlers ---
  const handleCreatePix = async (amountOverride?: string, type: 'aura' | 'business' = 'aura', plan?: 'basic' | 'premium' | 'vip') => {
    const amount = amountOverride || billingAmount;
    if (!amount || parseFloat(amount) <= 0) return;
    setIsCheckingPayment(true);
    setPaymentType(type);
    if (plan) setPendingBusinessPlan(plan);
    
    try {
      const response = await fetch('/api/pix/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          amount: parseFloat(amount),
          description: `SafeTalk Business - ${user?.displayName || 'Usuário'}`,
          external_id: `${type}_${user?.uid}_${Date.now()}`
        })
      });
      const data = await response.json();
      if (data.id) {
        setTransactionId(data.id);
        setPixCode(data.qrCodeText);
        setPaymentStatus('PENDING');
        setShowBillingModal(true);
        setShowBusinessPlans(false);
      }
    } catch (err) {
      console.error('Error creating PIX:', err);
    } finally {
      setIsCheckingPayment(false);
    }
  };

  const checkPaymentStatus = useCallback(async () => {
    if (!transactionId || paymentStatus === 'COMPLETED') return;
    try {
      const response = await fetch(`/api/pix/status?id=${transactionId}`);
      const data = await response.json();
      if (data.status === 'COMPLETED') {
        setPaymentStatus('COMPLETED');
        
        if (paymentType === 'aura') {
          const hours = (parseFloat(billingAmount) / 10) * 24;
          const auraUntil = Date.now() + (hours * 60 * 60 * 1000);
          
          if (user?.uid) {
            await setDoc(doc(db, 'users', user.uid), {
              auraUntil: auraUntil
            }, { merge: true });
            setUser({ ...user, auraUntil });
          }
        } else if (paymentType === 'business' && pendingBusinessPlan) {
          const businessData = {
            isBusiness: true,
            businessPlan: pendingBusinessPlan,
            isAiEnabled: true,
            businessBio: user?.displayName || 'Minha Empresa',
            businessLocation: '',
            businessPhotos: [],
            businessVerified: pendingBusinessPlan === 'vip'
          };
          
          if (user?.uid) {
            await setDoc(doc(db, 'users', user.uid), businessData, { merge: true });
            setUser({ ...user, ...businessData });
          }
        }
        
        // Reset billing state after a delay or immediately
        setTimeout(() => {
          setShowBillingModal(false);
          setPixCode(null);
          setTransactionId(null);
          setPaymentStatus(null);
          setBillingAmount('');
          setPendingBusinessPlan(null);
        }, 3000);
      }
    } catch (err) {
      console.error('Error checking status:', err);
    }
  }, [transactionId, paymentStatus, billingAmount, user, db, paymentType, pendingBusinessPlan]);

  useEffect(() => {
    let interval: any;
    if (transactionId && paymentStatus === 'PENDING') {
      interval = setInterval(() => {
        checkPaymentStatus();
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [transactionId, paymentStatus, checkPaymentStatus]);

  const calculateAuraTime = (amount: string) => {
    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) return '0 horas';
    const hours = (val / 10) * 24;
    if (hours < 1) return `${Math.round(hours * 60)} minutos`;
    return `${hours.toFixed(1)} horas`;
  };
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  const [showFabMenu, setShowFabMenu] = useState(false);
  const [showContactsModal, setShowContactsModal] = useState(false);
  const [allUsers, setAllUsers] = useState<any[]>([]);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstallBanner(true);
    });

    window.addEventListener('appinstalled', () => {
      setShowInstallBanner(false);
      setDeferredPrompt(null);
    });
  }, []);

  const handleInstallApp = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setShowInstallBanner(false);
    }
    setDeferredPrompt(null);
  };

  useEffect(() => {
    if (window.PublicKeyCredential) {
      PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
        .then(available => setIsBiometricSupported(available));
    }
  }, []);

  useEffect(() => {
    if (user) {
      const enabled = localStorage.getItem(`biometric_enabled_${user.uid}`) === 'true';
      setIsBiometricEnabled(enabled);
      if (enabled) {
        setIsAppLocked(true);
      }
    }
  }, [user]);

  const verifyBiometric = async (): Promise<boolean> => {
    setIsVerifyingBiometric(true);
    try {
      // Check if we are in an iframe
      const isIframe = window.self !== window.top;
      
      if (!window.PublicKeyCredential) {
        throw new Error('WebAuthn não suportado');
      }

      const challenge = new Uint8Array(32);
      window.crypto.getRandomValues(challenge);

      const options: any = {
        publicKey: {
          challenge,
          rp: { 
            name: "SafeTalk Brasil",
            id: window.location.hostname 
          },
          user: {
            id: new TextEncoder().encode(user.uid.slice(0, 16)),
            name: user.email || user.uid,
            displayName: user.displayName || "Usuário SafeTalk"
          },
          pubKeyCredParams: [
            { alg: -7, type: "public-key" }, 
            { alg: -257, type: "public-key" }
          ],
          authenticatorSelection: {
            userVerification: "required",
            authenticatorAttachment: "platform",
            residentKey: "preferred"
          },
          timeout: 60000
        }
      };

      await navigator.credentials.create(options);
      return true;
    } catch (err: any) {
      console.error('Biometric verification error:', err);
      
      // Specific error handling for iframes
      if (window.self !== window.top) {
        setError('A biometria é bloqueada em janelas incorporadas. Clique no ícone de "Abrir em nova aba" no topo para testar a biometria real.');
      } else {
        setError('Erro na biometria: ' + (err.message || 'Verifique as configurações do seu dispositivo.'));
      }
      return false;
    } finally {
      setIsVerifyingBiometric(false);
    }
  };

  const toggleBiometric = async () => {
    if (!isBiometricSupported) {
      setError('Seu dispositivo não suporta biometria ou senha do sistema.');
      return;
    }

    const success = await verifyBiometric();
    if (success) {
      const newState = !isBiometricEnabled;
      setIsBiometricEnabled(newState);
      localStorage.setItem(`biometric_enabled_${user.uid}`, String(newState));
      setWelcomeMessage(newState ? 'Proteção por biometria ativada!' : 'Proteção por biometria desativada.');
      setTimeout(() => setWelcomeMessage(null), 3000);
    } else {
      setError('Falha na verificação de segurança.');
    }
  };

  const handleUnlock = async () => {
    const success = await verifyBiometric();
    if (success) {
      setIsAppLocked(false);
    }
  };

  const LockScreen = () => (
    <div className="fixed inset-0 bg-[#001F3F] z-[200] flex flex-col items-center justify-center p-8">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="flex flex-col items-center gap-8 text-center"
      >
        <div className="w-24 h-24 bg-[#EC6608] rounded-[2rem] flex items-center justify-center shadow-2xl shadow-orange-500/20">
          <ShieldCheck size={48} className="text-white" />
        </div>
        
        <div className="space-y-2">
          <h2 className="text-2xl font-black text-white">SafeTalk Bloqueado</h2>
          <p className="text-white/60 text-sm">Use sua biometria ou senha do celular para acessar suas conversas seguras.</p>
          {window.self !== window.top && (
            <p className="text-orange-400 text-[10px] font-bold mt-2 uppercase tracking-tighter bg-orange-400/10 py-1 px-2 rounded-lg inline-block">
              ⚠️ Abra em nova aba para usar biometria real
            </p>
          )}
        </div>

        <button 
          onClick={handleUnlock}
          disabled={isVerifyingBiometric}
          className="bg-[#EC6608] text-white px-8 py-4 rounded-2xl font-bold shadow-lg active:scale-95 transition-all flex items-center gap-3"
        >
          {isVerifyingBiometric ? (
            <RotateCw className="animate-spin" size={20} />
          ) : (
            <ShieldCheck size={20} />
          )}
          DESBLOQUEAR AGORA
        </button>

        {/* Logout button removed as per user request */}
      </motion.div>
    </div>
  );

  useEffect(() => {
    let loadingTimer: any;
    
    const initApp = async () => {
      try {
        const logo = await generateLogo();
        if (logo) setAppLogo(logo);
      } catch (err) {
        console.error('Logo generation error:', err);
      }
    };
    
    initApp();
    return () => {
      if (loadingTimer) clearTimeout(loadingTimer);
    };
  }, []);

  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, 'callHistory'),
        where('participants', 'array-contains', user.uid),
        limit(50) // Fetch a bit more to sort client-side
      );
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const history = snapshot.docs
          .map(doc => ({ id: doc.id, ...doc.data() }))
          .sort((a: any, b: any) => {
            const timeA = a.timestamp?.toMillis?.() || a.timestamp?.seconds * 1000 || 0;
            const timeB = b.timestamp?.toMillis?.() || b.timestamp?.seconds * 1000 || 0;
            return timeB - timeA;
          })
          .slice(0, 20); // Keep only top 20 after sorting
        setCallHistory(history);
      });
      return () => unsubscribe();
    }
  }, [user]);

  const activeChatRef = useRef<any>(activeChat);
  useEffect(() => {
    activeChatRef.current = activeChat;
  }, [activeChat]);

  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, 'chats'),
        where('participants', 'array-contains', user.uid)
      );
      const unsubscribe = onSnapshot(q, async (snapshot) => {
        const chatList = await Promise.all(snapshot.docs.map(async (chatDoc) => {
          const data = chatDoc.data() as any;
          const otherParticipantId = data.participants.find((uid: string) => uid !== user.uid);
          
          let auraUntil = 0;
          let isBusiness = false;
          let businessPlan = null;
          let businessVerified = false;
          
          if (otherParticipantId) {
            const userDoc = await getDocs(query(collection(db, 'users'), where('uid', '==', otherParticipantId)));
            if (!userDoc.empty) {
              const userData = userDoc.docs[0].data();
              auraUntil = userData.auraUntil || 0;
              isBusiness = userData.isBusiness || false;
              businessPlan = userData.businessPlan || null;
              businessVerified = userData.businessVerified || false;
            }
          }
          
          return { id: chatDoc.id, ...data, auraUntil, isBusiness, businessPlan, businessVerified } as any;
        }));

        const sortedChats = chatList.sort((a: any, b: any) => {
          const timeA = a.timestamp?.toMillis?.() || a.timestamp?.seconds * 1000 || 0;
          const timeB = b.timestamp?.toMillis?.() || b.timestamp?.seconds * 1000 || 0;
          return timeB - timeA;
        });
        
        setChats(sortedChats);
        
        // Update activeChat if it exists to reflect latest typing status
        if (activeChatRef.current) {
          const currentChat = activeChatRef.current as any;
          const updatedActiveChat = sortedChats.find(c => c.id === currentChat.id);
          if (updatedActiveChat) {
            // Only update if it's actually different to avoid infinite loops
            const hasChanged = 
              updatedActiveChat.lastMessage !== currentChat.lastMessage ||
              updatedActiveChat.unreadCount !== currentChat.unreadCount ||
              JSON.stringify(updatedActiveChat.typing) !== JSON.stringify(currentChat.typing);

            if (hasChanged) {
              setActiveChat(updatedActiveChat as any);
            }
            
            // Check for typing indicator
            const otherParticipantId = (updatedActiveChat as any).participants.find((uid: string) => uid !== user.uid);
            if ((updatedActiveChat as any).typing && (updatedActiveChat as any).typing[otherParticipantId]) {
              setTypingUser((updatedActiveChat as any).name);
            } else {
              setTypingUser(null);
            }
          }
        }
      });
      return () => unsubscribe();
    }
  }, [user?.uid]); // Removed activeChat from dependencies to prevent loop

  useEffect(() => {
    if (user) {
      const now = new Date();
      const q = query(
        collection(db, 'statuses'),
        where('expiresAt', '>', now),
        orderBy('expiresAt', 'desc')
      );
      const unsubscribe = onSnapshot(q, async (snapshot) => {
        const statusList = await Promise.all(snapshot.docs.map(async (statusDoc) => {
          const data = statusDoc.id === 'talk-ai' ? null : statusDoc.data();
          if (!data) return null;
          
          // Fetch user info for each status to check for Aura
          const userDoc = await getDocs(query(collection(db, 'users'), where('uid', '==', data.userId)));
          const userData = userDoc.empty ? {} : userDoc.docs[0].data();
          
          const isOwnStatus = data.userId === user.uid;
          const isContactStatus = user.contacts && user.contacts.includes(data.userId);
          const hasAura = (userData.auraUntil && userData.auraUntil > Date.now()) || userData.isBusiness;
          const isBusiness = userData.isBusiness || false;
          
          // Visibility check: Show if author is in user's contacts OR it's the user's own status OR author has Aura (Public Ad) OR is Business
          if (!isOwnStatus && !isContactStatus && !hasAura && !isBusiness) return null;
          
          return { id: statusDoc.id, ...data, user: userData, hasAura, isBusiness };
        }));
        
        // Sort: Aura or Business statuses first, then by date
        const sortedStatuses = statusList
          .filter(s => s !== null)
          .sort((a: any, b: any) => {
            const priorityA = a.hasAura || a.isBusiness;
            const priorityB = b.hasAura || b.isBusiness;
            if (priorityA && !priorityB) return -1;
            if (!priorityA && priorityB) return 1;
            const timeA = a.createdAt?.toMillis?.() || a.createdAt?.seconds * 1000 || 0;
            const timeB = b.createdAt?.toMillis?.() || b.createdAt?.seconds * 1000 || 0;
            return timeB - timeA;
          });
          
        setStatuses(sortedStatuses);
      });
      return () => unsubscribe();
    }
  }, [user, user?.contacts]);

  const playNotification = (chatId: string) => {
    const chat = chats.find(c => c.id === chatId);
    const soundId = chat?.notificationSound || 'default';
    const vibrationId = chat?.vibrationPattern || 'default';

    const sound = NOTIFICATION_SOUNDS.find(s => s.id === soundId);
    if (sound) {
      const audio = new Audio(sound.url);
      audio.play().catch(e => console.error('Error playing sound:', e));
    }

    const vibration = VIBRATION_PATTERNS.find(v => v.id === vibrationId);
    if (vibration && vibration.pattern.length > 0 && 'vibrate' in navigator) {
      navigator.vibrate(vibration.pattern);
    }
  };

  useEffect(() => {
    if (user && chats.length > 0) {
      const lastChat = chats[0]; // Since it's ordered by timestamp desc
      if (lastChat.timestamp && lastChat.lastMessage && lastChat.lastSenderId) {
        const msgTime = lastChat.timestamp.toDate ? lastChat.timestamp.toDate() : new Date(lastChat.timestamp);
        const now = new Date();
        // If message is newer than 2 seconds and not sent by me
        if (now.getTime() - msgTime.getTime() < 2000 && lastChat.lastSenderId !== user.uid) {
          playNotification(lastChat.id);
        }
      }
    }
  }, [chats]);

  const handlePostStatus = async () => {
    console.log('Attempting to post status:', { statusType, statusText, statusImage, statusVideo });
    if (!user || (!statusText && !statusImage && !statusVideo)) {
      console.warn('Cannot post status: missing user or content');
      return;
    }
    setLoading(true);
    try {
      const createdAt = new Date();
      const expiresAt = new Date(createdAt.getTime() + 24 * 60 * 60 * 1000);
      
      const statusData = {
        userId: user.uid,
        type: statusType,
        content: statusType === 'text' ? statusText : (statusType === 'image' ? statusImage : statusVideo),
        backgroundColor: statusType === 'text' ? statusColor : null,
        filter: statusFilter,
        link: statusLink,
        createdAt: serverTimestamp(),
        expiresAt: expiresAt,
        user: {
          displayName: user.displayName,
          photoURL: user.photoURL
        }
      };
      
      console.log('Sending status data to Firestore:', statusData);
      const docRef = await addDoc(collection(db, 'statuses'), statusData);
      console.log('Status posted successfully with ID:', docRef.id);
      setShowStatusModal(false);
      setStatusText('');
      setStatusImage(null);
      setStatusVideo(null);
      setStatusFilter('none');
      setStatusLink('');
      setShowStatusOptions(false);
    } catch (err) {
      console.error('Error posting status:', err);
      setError('Erro ao postar status.');
    } finally {
      setLoading(false);
    }
  };
  const handleFlipCamera = async () => {
    if (callType !== 'video' || !localStreamRef.current) return;
    
    const newFacingMode = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(newFacingMode);
    
    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: newFacingMode },
        audio: true
      });
      
      const videoTrack = newStream.getVideoTracks()[0];
      const audioTrack = newStream.getAudioTracks()[0];
      
      if (pcRef.current) {
        const sender = (pcRef.current as any)._pc.getSenders().find((s: any) => s.track.kind === 'video');
        if (sender) sender.replaceTrack(videoTrack);
      }
      
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = newStream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = newStream;
      }
    } catch (err) {
      console.error('Error flipping camera:', err);
    }
  };
  
  // UI States
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAttachmentMenuOpen, setIsAttachmentMenuOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showSecurityCard, setShowSecurityCard] = useState(false);
  const [selectedPlanForDetails, setSelectedPlanForDetails] = useState<string | null>(null);
  
  // Notification States
  const [msgNotifications, setMsgNotifications] = useState(true);
  const [callNotifications, setCallNotifications] = useState(true);
  
  // Audio Recording States
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  
  // Auth States
  const [authStep, setAuthStep] = useState<AuthStep>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [emailCode, setEmailCode] = useState('');
  const [userName, setUserName] = useState('');
  const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
   // Call States
  const [isIncomingCall, setIsIncomingCall] = useState(false);
  const [activeCallId, setActiveCallId] = useState<string | null>(null);
  const [callStatus, setCallStatus] = useState<'idle' | 'ringing' | 'connected'>('idle');
  const [callType, setCallType] = useState<'voice' | 'video'>('video');
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const pcRef = useRef<any>(null);
  const isConnectingRef = useRef<boolean>(false);
  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteStreamRef = useRef<MediaStream | null>(null);
  const ringtoneRef = useRef<HTMLAudioElement | null>(null);
  const zegoContainerRef = useRef<HTMLDivElement | null>(null);
  const zegoJoinedRef = useRef(false);

  const ZEGO_APP_ID = 1539843249;
  const ZEGO_SERVER_SECRET = "55e96d7aef34ed124377c2e5147e34a9";

  const servers = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' }
    ],
    iceCandidatePoolSize: 10,
  };

  // Handle track enabling/disabling (Mute/Camera Toggle)
  useEffect(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getVideoTracks().forEach(track => {
        track.enabled = isCameraOn && callType === 'video';
      });
      localStreamRef.current.getAudioTracks().forEach(track => {
        track.enabled = isMicOn;
      });
    }
  }, [isCameraOn, isMicOn, callType]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        handleSendAudioMessage(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
    } catch (err) {
      console.error('Error accessing microphone:', err);
      setError('Erro ao acessar o microfone. Verifique as permissões.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  useEffect(() => {
    let interval: any;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);


  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Ringtone and Vibration for Incoming Calls
  useEffect(() => {
    if (callStatus === 'ringing') {
      if (!ringtoneRef.current) {
        // Using a standard ringtone sound
        ringtoneRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/1359/1359-preview.mp3');
        ringtoneRef.current.loop = true;
      }
      ringtoneRef.current.play().catch(e => console.log('Autoplay blocked or error:', e));
      
      if (isIncomingCall && 'vibrate' in navigator) {
        navigator.vibrate([500, 500, 500, 500, 500]);
      }
    } else {
      if (ringtoneRef.current) {
        ringtoneRef.current.pause();
        ringtoneRef.current.currentTime = 0;
      }
      if ('vibrate' in navigator) {
        navigator.vibrate(0);
      }
    }
  }, [callStatus, isIncomingCall]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        // Check if user has completed email step in Firestore
        checkUserProfile(currentUser);
      } else {
        setUser(null);
        setAuthStep('phone');
        setIsAppLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (user?.uid) {
      const unsubscribe = onSnapshot(doc(db, 'users', user.uid), (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          setUser((prev: any) => ({ ...prev, ...data }));
        }
      });
      return () => unsubscribe();
    }
  }, [user?.uid]);

  const callSubscriptionsRef = useRef<(() => void)[]>([]);

  const handleEndCall = useCallback(async () => {
    if (activeCallId) {
      const callDoc = await getDoc(doc(db, 'calls', activeCallId));
      if (callDoc.exists()) {
        const data = callDoc.data();
        // Save to history
        await addDoc(collection(db, 'callHistory'), {
          callerId: data.callerId,
          callerName: data.callerName,
          callerAvatar: data.callerAvatar,
          recipientId: data.recipientId,
          recipientName: data.recipientName,
          recipientAvatar: data.recipientAvatar,
          type: data.type,
          status: callStatus === 'connected' ? 'completed' : (data.callerId === user?.uid ? 'cancelled' : 'missed'),
          timestamp: serverTimestamp(),
          participants: [data.callerId, data.recipientId],
          duration: callStatus === 'connected' ? (document.getElementById('call-duration')?.innerText || '0:00') : null
        });
      }
      await deleteDoc(doc(db, 'calls', activeCallId));
    }
    
    // Unsubscribe from signaling listeners
    callSubscriptionsRef.current.forEach(unsub => unsub());
    callSubscriptionsRef.current = [];

    if (pcRef.current) {
      pcRef.current.destroy();
      pcRef.current = null;
    }
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }
    if (remoteStreamRef.current) {
      remoteStreamRef.current.getTracks().forEach(track => track.stop());
      remoteStreamRef.current = null;
    }
    
    setIsIncomingCall(false);
    setCallStatus('idle');
    setActiveCallId(null);
    setIsRemoteVideoLoading(true);
    isConnectingRef.current = false;
  }, [activeCallId, callStatus, user?.uid]);

  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, 'calls'),
        where('recipientId', '==', user.uid),
        where('status', '==', 'ringing'),
        limit(1)
      );
      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const callData = snapshot.docs[0].data();
          if (callData.callerId !== user.uid && !activeCallId) {
            console.log('Incoming call detected:', snapshot.docs[0].id);
            setCurrentCallData(callData);
            setIsIncomingCall(true);
            setCallType(callData.type || 'video');
            setCallStatus('ringing');
            setActiveCallId(snapshot.docs[0].id);
          }
        } else {
          // If we were ringing but the call document is gone (cancelled)
          if (callStatus === 'ringing' && isIncomingCall) {
            console.log('Incoming call cancelled by caller');
            handleEndCall();
          }
        }
      });
      return () => unsubscribe();
    }
  }, [user?.uid, activeCallId, callStatus, isIncomingCall, handleEndCall]);

  const handleStartCall = async (type: 'voice' | 'video') => {
    if (!activeChat || !user) return;
    
    setCallType(type);
    setIsCameraOn(type === 'video');
    
    try {
      console.log('Starting WebRTC call of type:', type);
      
      // 1. Get Local Stream
      const stream = await navigator.mediaDevices.getUserMedia({
        video: type === 'video' ? { facingMode: 'user' } : false,
        audio: true
      });
      localStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      // 2. Create call document for signaling
      const callRef = doc(collection(db, 'calls'));
      const recipientId = activeChat.participants.find((uid: string) => uid !== user.uid);

      // 3. Initialize Peer
      const peer = new Peer({
        initiator: true,
        trickle: false,
        stream: stream,
        config: servers
      });

      peer.on('signal', async (data) => {
        await setDoc(callRef, {
          callerId: user.uid,
          callerName: user.displayName,
          callerAvatar: user.photoURL,
          recipientId: recipientId,
          recipientName: activeChat.name,
          recipientAvatar: activeChat.avatar,
          type,
          status: 'ringing',
          timestamp: serverTimestamp(),
          participants: [user.uid, recipientId],
          offer: JSON.stringify(data)
        });
      });

      peer.on('stream', (remoteStream) => {
        console.log('Remote stream received');
        remoteStreamRef.current = remoteStream;
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = remoteStream;
        }
        setIsRemoteVideoLoading(false);
      });

      peer.on('close', () => handleEndCall());
      peer.on('error', (err) => {
        console.error('Peer error in handleStartCall:', err);
        // Only end call if it's a fatal error or if we're not connected yet
        if (callStatus !== 'connected' || err.code === 'ERR_CONNECTION_FAILED') {
          handleEndCall();
        }
      });

      pcRef.current = peer;
      setActiveCallId(callRef.id);
      setCallStatus('ringing');
      setIsIncomingCall(false);

      // Listen for answer
      const unsub = onSnapshot(callRef, (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          if (data.answer && !isConnectingRef.current) {
            try {
              isConnectingRef.current = true;
              peer.signal(JSON.parse(data.answer));
              setCallStatus('connected');
            } catch (signalErr) {
              console.error('Error signaling answer:', signalErr);
              isConnectingRef.current = false;
            }
          }
        } else {
          handleEndCall();
        }
      });
      callSubscriptionsRef.current.push(unsub);

    } catch (err) {
      console.error('Error starting call:', err);
      setError('Erro ao iniciar chamada. Verifique as permissões.');
    }
  };

  const handleAcceptCall = useCallback(async () => {
    if (!activeCallId || !user || !currentCallData) return;
    
    try {
      console.log('Accepting WebRTC call:', activeCallId);
      
      // 1. Get Local Stream
      const stream = await navigator.mediaDevices.getUserMedia({
        video: currentCallData.type === 'video' ? { facingMode: 'user' } : false,
        audio: true
      });
      localStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      // 2. Initialize Peer
      const peer = new Peer({
        initiator: false,
        trickle: false,
        stream: stream,
        config: servers
      });

      peer.on('signal', async (data) => {
        const callRef = doc(db, 'calls', activeCallId);
        await setDoc(callRef, { 
          status: 'connected',
          answer: JSON.stringify(data)
        }, { merge: true });
      });

      peer.on('stream', (remoteStream) => {
        console.log('Remote stream received');
        remoteStreamRef.current = remoteStream;
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = remoteStream;
        }
        setIsRemoteVideoLoading(false);
      });

      peer.on('close', () => handleEndCall());
      peer.on('error', (err) => {
        console.error('Peer error in handleAcceptCall:', err);
        if (callStatus !== 'connected' || err.code === 'ERR_CONNECTION_FAILED') {
          handleEndCall();
        }
      });

      try {
        peer.signal(JSON.parse(currentCallData.offer));
        pcRef.current = peer;
        isConnectingRef.current = true;
        setCallStatus('connected');
        setIsIncomingCall(false);
      } catch (signalErr) {
        console.error('Error signaling offer:', signalErr);
        handleEndCall();
      }

      // Listen for call termination
      const unsub = onSnapshot(doc(db, 'calls', activeCallId), (snapshot) => {
        if (!snapshot.exists()) {
          handleEndCall();
        }
      });
      callSubscriptionsRef.current.push(unsub);

    } catch (err) {
      console.error('Error accepting call:', err);
      setError('Erro ao atender chamada. Verifique as permissões.');
    }
  }, [activeCallId, user, currentCallData, handleEndCall]);

  useEffect(() => {
    if (activeCallId) {
      const unsubscribe = onSnapshot(doc(db, 'calls', activeCallId), (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          if (data.status === 'connected') {
            setCallStatus('connected');
          }
        } else {
          // Call document deleted (ended by other party)
          handleEndCall();
        }
      });
      return () => unsubscribe();
    }
  }, [activeCallId, handleEndCall]);

  useEffect(() => {
    if (user) {
      const params = new URLSearchParams(window.location.search);
      const chatId = params.get('chatId');
      const callId = params.get('callId');
      const action = params.get('action');

      if (chatId && chats.length > 0) {
        const chat = chats.find(c => c.id === chatId);
        if (chat) {
          setActiveChat(chat);
          setView('chat');
          window.history.replaceState({}, document.title, "/");
        }
      }

      if (callId) {
        setActiveCallId(callId);
        setIsIncomingCall(true);
        setCallStatus('ringing');
        
        // Fetch call data to set callType correctly
        getDoc(doc(db, 'calls', callId)).then(docSnap => {
          if (docSnap.exists()) {
            const data = docSnap.data();
            setCurrentCallData(data);
            setCallType(data.type || 'video');
            
            if (action === 'accept') {
              handleAcceptCall();
            } else if (action === 'decline') {
              handleEndCall();
            }
          }
        });
        
        window.history.replaceState({}, document.title, "/");
      }
    }
  }, [user, chats, handleAcceptCall, handleEndCall]);

  const checkUserProfile = async (currentUser: User) => {
    try {
      const userDocRef = doc(db, 'users', currentUser.uid);
      const userDoc = await getDoc(userDocRef);
      
      if (userDoc.exists()) {
        const data = userDoc.data();
        if (data.emailVerified) {
          setUser(data); // Load full user data from Firestore
          setUserName(data.displayName || '');
          setProfilePhoto(data.photoURL || null);
          setupNotifications();
          setWelcomeMessage(`Bem-vindo de volta, ${data.displayName}!`);
          setTimeout(() => setWelcomeMessage(null), 4000);
        } else {
          setAuthStep('email');
        }
      } else {
        setAuthStep('email');
      }
    } catch (err) {
      console.error('Error checking user profile:', err);
      setAuthStep('email');
    } finally {
      setIsAppLoading(false);
    }
  };

  useEffect(() => {
    if (view === 'chat' && activeChat && user) {
      const q = query(
        collection(db, 'chats', activeChat.id, 'messages'),
        orderBy('timestamp', 'asc'),
        limit(50)
      );
      
      let lastMessageCount = 0;

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
        setMessages(msgs);
        
        // Mark messages as read efficiently
        const unreadDocs = snapshot.docs.filter(doc => {
          const data = doc.data();
          return data.senderId !== user.uid && !data.isRead;
        });

        if (unreadDocs.length > 0) {
          unreadDocs.forEach(msgDoc => {
            setDoc(doc(db, 'chats', activeChat.id, 'messages', msgDoc.id), {
              isRead: true
            }, { merge: true }).catch(err => console.error("Error marking as read:", err));
          });
        }

        // Only scroll if new messages arrived
        if (msgs.length > lastMessageCount) {
          setTimeout(() => {
            scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
          }, 100);
        }
        lastMessageCount = msgs.length;
      });
      return () => unsubscribe();
    }
  }, [view, activeChat?.id, user?.uid]);

  const setupNotifications = async () => {
    const token = await requestForToken();
    if (token && user) {
      console.log('FCM Token ready:', token);
      await setDoc(doc(db, 'users', user.uid), { fcmToken: token }, { merge: true });
    }
    
    if (messaging) {
      onMessage(messaging, (payload: any) => {
        console.log('Notification received in foreground:', payload);
        if (payload.data?.type === 'call') {
          const callData = payload.data;
          setActiveCallId(callData.callId);
          setCurrentCallData({
            callerId: callData.callerId,
            callerName: callData.callerName,
            callerAvatar: callData.callerAvatar,
            type: callData.callType || 'video'
          });
          setCallType(callData.callType || 'video');
          setIsIncomingCall(true);
          setCallStatus('ringing');
        }
      });
    }
  };

  const handleSendCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    
    if (!phoneNumber.trim()) {
      setError('Por favor, insira seu número de telefone.');
      setLoading(false);
      return;
    }

    try {
      // Check if user already exists with this phone number
      const q = query(collection(db, 'users'), where('phoneNumber', '==', cleanPhone));
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        // User exists! Log them in directly as requested
        const userData = querySnapshot.docs[0].data();
        setUser(userData);
        setupNotifications();
        // Skip to home view
        setView('home');
        setLoading(false);
        return;
      }

      // Bypass para o número específico do administrador/teste
      if (cleanPhone === '86995728793' || cleanPhone === '5586995728793') {
        setEmail('admin@safetalk.com'); // E-mail padrão para o bypass
        setAuthStep('profile-setup');
        setLoading(false);
        return;
      }

      // New user: go to email step
      setAuthStep('email');
    } catch (err) {
      console.error('Error checking user:', err);
      setError('Erro ao verificar usuário. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleSendEmailCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Check if email is already used by another user
      const q = query(collection(db, 'users'), where('email', '==', email));
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        setError('Este e-mail já está em uso por outro usuário.');
        setLoading(false);
        return;
      }

      const response = await fetch('/api/send-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Erro HTTP: ${response.status}`);
      }

      const data = await response.json();
      if (data.success) {
        setAuthStep('email-verify');
      } else {
        setError(data.error || 'Erro ao enviar o código. Tente novamente.');
      }
    } catch (err: any) {
      console.error('Erro ao enviar e-mail:', err);
      setError(err.message || 'Não foi possível conectar ao servidor. Verifique sua internet.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyEmailCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Código mestre para o e-mail de bypass
      if (email === 'admin@safetalk.com' && emailCode === '123456') {
        setAuthStep('profile-setup');
        return;
      }

      const response = await fetch('/api/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code: emailCode }),
      });

      const data = await response.json();
      if (data.success) {
        setAuthStep('profile-setup');
      } else {
        setError(data.error || 'Código inválido.');
      }
    } catch (err) {
      setError('Erro ao verificar código.');
    } finally {
      setLoading(false);
    }
  };

  const handleProfileSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim()) {
      setError('Por favor, insira seu nome.');
      return;
    }
    setAuthStep('permissions');
  };

  const handleRequestPermissions = async () => {
    setLoading(true);
    setError('');
    
    try {
      // 1. Request Camera and Microphone permissions
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      stream.getTracks().forEach(track => track.stop());

      // 2. Request Notifications permission
      if ('Notification' in window) {
        const permission = await Notification.requestPermission();
        console.log('Notification permission:', permission);
      }

      // 3. Register Service Worker for background execution
      if ('serviceWorker' in navigator) {
        try {
          const registration = await navigator.serviceWorker.register('/sw.js');
          console.log('Service Worker registered:', registration);
        } catch (err) {
          console.error('Service Worker registration failed:', err);
        }
      }

      const cleanPhone = phoneNumber.replace(/\D/g, '');
      
      // Save user data permanently to Firestore
      const finalUser = {
        uid: user?.uid || `user_${Date.now()}`,
        phoneNumber: cleanPhone,
        email: email,
        displayName: userName,
        photoURL: profilePhoto || `https://picsum.photos/seed/${userName}/200`,
        emailVerified: true,
        lastSeen: serverTimestamp(),
        settings: {
          msgNotifications: true,
          callNotifications: true
        }
      };
      
      await setDoc(doc(db, 'users', finalUser.uid), finalUser, { merge: true });

      setUser(finalUser);
      setupNotifications();
    } catch (err) {
      console.error('Permission error:', err);
      setError('Para o SafeTalk funcionar, você precisa autorizar o acesso à câmera, microfone e localização no sistema do seu celular.');
    } finally {
      setLoading(false);
    }
  };

  const handleViewContacts = async () => {
    if (!user) return;
    setShowContactsModal(true);
    setLoading(true);
    
    try {
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      const contactIds = userDoc.data()?.contacts || [];
      
      if (contactIds.length === 0) {
        setAllUsers([]);
        setLoading(false);
        return;
      }

      // Firestore 'in' query supports up to 10 items. For more, we'd need to chunk.
      // But for this app, we'll fetch them and filter.
      const usersSnapshot = await getDocs(collection(db, 'users'));
      const usersList = usersSnapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() }))
        .filter(u => contactIds.includes(u.id));
      setAllUsers(usersList);
    } catch (err) {
      console.error('Error fetching contacts:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStartChatWithUser = async (targetUser: any) => {
    // Check if chat already exists
    const q = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', user?.uid)
    );
    const snapshot = await getDocs(q);
    const existingChat = snapshot.docs.find(doc => {
      const data = doc.data();
      return data.participants.includes(targetUser.id) && data.participants.length === 2;
    });

    if (existingChat) {
      setActiveChat({ id: existingChat.id, ...existingChat.data() } as any);
      setView('chat');
    } else {
      const newChatRef = await addDoc(collection(db, 'chats'), {
        name: targetUser.displayName || 'Contato',
        lastMessage: 'Iniciou uma nova conversa',
        timestamp: serverTimestamp(),
        avatar: targetUser.photoURL || `https://picsum.photos/seed/${targetUser.id}/200`,
        participants: [user?.uid, targetUser.id]
      });
      setActiveChat({ 
        id: newChatRef.id, 
        name: targetUser.displayName || 'Contato',
        avatar: targetUser.photoURL || `https://picsum.photos/seed/${targetUser.id}/200`,
        participants: [user?.uid, targetUser.id]
      } as any);
      setView('chat');
    }
    setShowContactsModal(false);
  };

  const handleUpdateProfile = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const updatedData = {
        displayName: userName,
        photoURL: profilePhoto || user.photoURL,
        lastSeen: serverTimestamp()
      };
      
      await setDoc(doc(db, 'users', user.uid), updatedData, { merge: true });
      setUser({ ...user, ...updatedData });
      setIsEditingProfile(false);
    } catch (err) {
      setError('Erro ao atualizar perfil.');
    } finally {
      setLoading(false);
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTalkAI = async (text: string) => {
    if (!text.trim() || !user) return;
    setIsAiLoading(true);
    
    // Add user message locally
    const userMsg: Message = {
      id: Date.now().toString(),
      senderId: user.uid,
      text,
      timestamp: { toDate: () => new Date() },
      type: 'text'
    };
    setMessages(prev => [...prev, userMsg]);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      if (text.toLowerCase().includes('gere uma imagem') || text.toLowerCase().includes('crie uma imagem') || text.toLowerCase().includes('foto de')) {
        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash-image",
          contents: [{ parts: [{ text }] }]
        });
        
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const imageUrl = `data:image/png;base64,${part.inlineData.data}`;
            const aiMsg: Message = {
              id: (Date.now() + 1).toString(),
              senderId: 'talk-ai',
              type: 'image',
              url: imageUrl,
              timestamp: { toDate: () => new Date() }
            };
            setMessages(prev => [...prev, aiMsg]);
            break;
          }
        }
      } else {
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: text,
          config: {
            systemInstruction: "Você é o 'Talk AI', o assistente inteligente do aplicativo SafeTalk. Seja amigável, prestativo e fale em português brasileiro."
          }
        });
        const aiMsg: Message = {
          id: (Date.now() + 1).toString(),
          senderId: 'talk-ai',
          text: response.text,
          timestamp: { toDate: () => new Date() },
          type: 'text'
        };
        setMessages(prev => [...prev, aiMsg]);
      }
    } catch (err) {
      console.error('AI Error:', err);
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        senderId: 'talk-ai',
        text: "Desculpe, estou um pouco sobrecarregado no momento. Por favor, tente novamente mais tarde.",
        timestamp: { toDate: () => new Date() },
        type: 'text'
      };
      setMessages(prev => [...prev, aiMsg]);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleSearchAndAddContact = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchPhone.trim() || !user) return;
    
    setLoading(true);
    setError('');
    
    try {
      const cleanSearchPhone = searchPhone.replace(/\D/g, '');
      const q = query(collection(db, 'users'), where('phoneNumber', '==', cleanSearchPhone));
      const querySnapshot = await getDocs(q);
      
      if (!querySnapshot.empty) {
        const contactDoc = querySnapshot.docs[0];
        const contactData = contactDoc.data();
        
        if (contactData.uid === user.uid) {
          setError('Você não pode adicionar a si mesmo.');
          setLoading(false);
          return;
        }

        // Add to user's contacts list in Firestore
        const userRef = doc(db, 'users', user.uid);
        const userDoc = await getDoc(userRef);
        const currentContacts = userDoc.data()?.contacts || [];
        
        if (!currentContacts.includes(contactData.uid)) {
          await setDoc(userRef, {
            contacts: [...currentContacts, contactData.uid]
          }, { merge: true });
          
          // Update local state
          setUser({
            ...user,
            contacts: [...currentContacts, contactData.uid]
          });
        }

        // Check if chat already exists
        const existingChatQuery = query(
          collection(db, 'chats'),
          where('participants', 'array-contains', user.uid)
        );
        const existingChats = await getDocs(existingChatQuery);
        const alreadyExists = existingChats.docs.find(doc => {
          const data = doc.data();
          return data.isGroup === false && data.participants.includes(contactData.uid);
        });
        
        if (!alreadyExists) {
          // Create a new chat with this contact
          await addDoc(collection(db, 'chats'), {
            name: contactData.displayName,
            lastMessage: 'Iniciou uma nova conversa',
            timestamp: serverTimestamp(),
            avatar: contactData.photoURL || `https://picsum.photos/seed/${contactData.uid}/200`,
            participants: [user.uid, contactData.uid],
            isGroup: false
          });
        }
        
        setIsSearchingContact(false);
        setSearchPhone('');
        setWelcomeMessage(`Contato ${contactData.displayName} adicionado com sucesso!`);
        setTimeout(() => setWelcomeMessage(null), 3000);
      } else {
        setError('Usuário não encontrado com este número!');
      }
    } catch (err) {
      console.error('Error searching contact:', err);
      setError('Erro ao buscar contato.');
    } finally {
      setLoading(false);
    }
  };
  const handleCreateGroup = async () => {
    if (!groupName.trim() || !user) return;
    try {
      const newChatRef = await addDoc(collection(db, 'chats'), {
        name: groupName,
        lastMessage: 'Grupo criado',
        timestamp: serverTimestamp(),
        avatar: `https://picsum.photos/seed/${groupName}/200`,
        participants: [user.uid, ...groupParticipants],
        isGroup: true
      });
      setShowGroupModal(false);
      setGroupName('');
      setGroupParticipants([]);
    } catch (err) {
      console.error('Error creating group:', err);
    }
  };

  const typingTimeoutRef = useRef<any>(null);

  useEffect(() => {
    if (activeChat?.id && user && activeChat.id !== 'talk-ai') {
      const chatRef = doc(db, 'chats', activeChat.id);
      if (newMessage.length > 0) {
        setDoc(chatRef, {
          typing: { [user.uid]: true }
        }, { merge: true });
        
        if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = setTimeout(() => {
          setDoc(chatRef, {
            typing: { [user.uid]: false }
          }, { merge: true });
        }, 3000);
      } else {
        setDoc(chatRef, {
          typing: { [user.uid]: false }
        }, { merge: true });
      }
    }
  }, [newMessage, activeChat?.id, user?.uid]);

  const handleSendMessage = async (e?: React.FormEvent, mediaData?: Partial<Message>) => {
    if (e) e.preventDefault();
    if ((!newMessage.trim() && !mediaData) || !activeChat || !user) return;

    // Clear typing status immediately
    const chatRef = doc(db, 'chats', activeChat.id);
    await setDoc(chatRef, {
      typing: { [user.uid]: false }
    }, { merge: true });

    if (activeChat.id === 'talk-ai') {
      handleTalkAI(newMessage);
      setNewMessage('');
      return;
    }

    const msgType = mediaData?.type || 'text';
    const msgText = mediaData?.text || newMessage;
    
    if (!mediaData) setNewMessage('');

    const messageData: any = {
      senderId: user.uid,
      timestamp: serverTimestamp(),
      type: msgType,
      isRead: false,
      ...mediaData
    };

    if (msgType === 'text') messageData.text = msgText;

    try {
      const docRef = await addDoc(collection(db, 'chats', activeChat.id, 'messages'), messageData);
      console.log('Message sent with ID:', docRef.id);

      await setDoc(doc(db, 'chats', activeChat.id), {
        lastMessage: msgType === 'text' ? msgText : `[${msgType}]`,
        timestamp: serverTimestamp(),
        lastSenderId: user.uid,
        aiResponded: false // Reset AI response flag
      }, { merge: true });

      // Trigger notification for other user
      const recipientId = activeChat.participants.find((uid: string) => uid !== user.uid);
      if (recipientId) {
        const recipientDoc = await getDoc(doc(db, 'users', recipientId));
        if (recipientDoc.exists()) {
          const recipientData = recipientDoc.data();
          if (recipientData.fcmToken) {
            await fetch('/api/send-notification', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                token: recipientData.fcmToken,
                title: user.displayName || 'SafeTalk',
                body: msgType === 'text' ? msgText : `Enviou um(a) ${msgType}`,
                data: { 
                  type: 'message', 
                  chatId: activeChat.id,
                  senderId: user.uid,
                  senderName: user.displayName || 'SafeTalk'
                }
              })
            });
          }
        }
      }
    } catch (err) {
      console.error('Error sending message:', err);
      setError('Erro ao enviar mensagem. Verifique sua conexão.');
    }
  };

  const handleBusinessAiResponse = async (chatId: string, customerMessage: string) => {
    if (!user) return;
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      const prompt = `
        Você é o assistente virtual oficial da empresa "${user.businessBio || user.displayName}".
        Estamos no SafeTalk, um aplicativo de mensagens ultra-seguro.
        
        Regras de Resposta:
        1. Fale sempre em nome da empresa (use "Nós").
        2. Parabenize o cliente pela escolha da segurança do SafeTalk.
        3. Informe que o botão para ativar/desativar a IA 24h e as fotos do perfil ficam na aba Configurações.
        4. Seja profissional, prestativo e direto.
        
        Mensagem do Cliente: "${customerMessage}"
        
        Responda agora:
      `;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });
      const aiText = response.text;
      
      const messageData = {
        senderId: user.uid,
        timestamp: serverTimestamp(),
        type: 'text',
        text: aiText,
        isAi: true
      };
      
      await addDoc(collection(db, 'chats', chatId, 'messages'), messageData);
      await setDoc(doc(db, 'chats', chatId), {
        lastMessage: aiText,
        timestamp: serverTimestamp(),
        lastSenderId: user.uid,
        aiResponded: true
      }, { merge: true });
      
    } catch (err) {
      console.error('Error in Business AI response:', err);
    }
  };

  useEffect(() => {
    if (user?.isBusiness && user?.isAiEnabled) {
      const q = query(
        collection(db, 'chats'),
        where('participants', 'array-contains', user.uid)
      );
      
      const unsubscribe = onSnapshot(q, (snapshot) => {
        snapshot.docChanges().forEach(async (change) => {
          if (change.type === 'modified') {
            const chatData = change.doc.data();
            // Only respond if the last message was from someone else AND AI hasn't responded yet
            if (chatData.lastSenderId !== user.uid && chatData.lastMessage && chatData.aiResponded === false) {
              await handleBusinessAiResponse(change.doc.id, chatData.lastMessage);
            }
          }
        });
      });
      return () => unsubscribe();
    }
  }, [user?.isBusiness, user?.isAiEnabled, user?.uid]);

  const handleSendMedia = async (type: 'image' | 'video' | 'file' | 'location') => {
    setIsAttachmentMenuOpen(false);
    
    if (type === 'location') {
      navigator.geolocation.getCurrentPosition(async (pos) => {
        const { latitude, longitude } = pos.coords;
        await handleSendMessage(undefined, {
          type: 'location',
          locationData: { lat: latitude, lng: longitude, address: 'Localização atual' }
        });
      });
      return;
    }

    const input = document.createElement('input');
    input.type = 'file';
    if (type === 'image') input.accept = 'image/*';
    else if (type === 'video') input.accept = 'video/*';
    else if (type === 'file') input.accept = '.pdf,.doc,.docx,.txt';
    
    input.onchange = async (e: any) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = async () => {
        await handleSendMessage(undefined, {
          type: type,
          url: reader.result as string,
          fileName: file.name
        });
      };
      reader.readAsDataURL(file);
    };
    input.click();
  };

  const handleSendAudioMessage = async (audioBlob: Blob) => {
    if (!activeChat || !user) return;
    
    const reader = new FileReader();
    reader.onload = async () => {
      const base64Audio = reader.result as string;
      await handleSendMessage(undefined, {
        type: 'audio',
        url: base64Audio,
        duration: recordingTime
      });
    };
    reader.readAsDataURL(audioBlob);
  };

  // --- Views ---

  const LoginView = () => (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-md space-y-12">
        {/* Big Ball with Drawings (WhatsApp Style) */}
        <div className="flex flex-col items-center gap-4">
          <div className="text-center mb-2">
            <p className="text-[#EC6608] font-black text-xs uppercase tracking-[0.2em]">Novo aplicativo</p>
            <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest">Mais fácil de ser usado falar</p>
          </div>
          
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="w-48 h-48 rounded-full welcome-pattern flex items-center justify-center shadow-2xl relative overflow-hidden"
          >
            <ShieldCheck size={80} color="white" className="relative z-10 opacity-80" />
          </motion.div>
          
          <div className="text-center mt-4">
            <h1 className="text-4xl font-black text-[#EC6608] tracking-tight">SafeTalk</h1>
            <p className="text-gray-400 font-medium mt-1">Sua comunicação, protegida.</p>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {authStep === 'phone' && (
            <motion.form 
              key="phone"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleSendCode} 
              className="space-y-6"
            >
              <div className="text-center">
                <h2 className="text-xl font-bold text-[#001F3F]">Bem-vindo ao SafeTalk</h2>
                <p className="text-sm text-gray-500">Insira seu número de telefone para começar.</p>
              </div>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-[#EC6608]">+55</span>
                <input
                  type="tel"
                  placeholder="(00) 00000-0000"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full pl-16 pr-4 py-4 bg-gray-50 border-b-2 border-[#EC6608] outline-none text-lg font-bold"
                  required
                />
              </div>
              {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
              <button disabled={loading} className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-bold shadow-lg shadow-orange-100 active:scale-95 transition-all">
                {loading ? 'PROCESSANDO...' : 'AVANÇAR'}
              </button>
            </motion.form>
          )}

          {authStep === 'email' && (
            <motion.form 
              key="email"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleSendEmailCode} 
              className="space-y-6"
            >
              <div className="text-center">
                <h2 className="text-xl font-bold text-[#001F3F]">Quase lá! Agora seu e-mail</h2>
                <p className="text-sm text-gray-500">Enviaremos um código de segurança para seu e-mail.</p>
              </div>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#EC6608]" size={20} />
                <input
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-gray-50 border-b-2 border-[#EC6608] outline-none text-lg font-medium"
                  required
                />
              </div>
              {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
              <button disabled={loading} className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-bold shadow-lg shadow-orange-100 active:scale-95 transition-all">
                {loading ? 'ENVIANDO...' : 'CONTINUAR'}
              </button>
            </motion.form>
          )}

          {authStep === 'email-verify' && (
            <motion.form 
              key="email-verify"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleVerifyEmailCode} 
              className="space-y-6"
            >
              <div className="text-center">
                <h2 className="text-xl font-bold text-[#001F3F]">Código do E-mail</h2>
                <p className="text-sm text-gray-500">Insira o código enviado para {email}</p>
              </div>
              <input
                type="text"
                placeholder="123456"
                value={emailCode}
                onChange={(e) => setEmailCode(e.target.value)}
                className="w-full px-4 py-4 bg-gray-50 border-b-2 border-[#EC6608] outline-none text-center text-3xl tracking-[0.5em] font-black"
                maxLength={6}
                required
              />
              {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
              <button disabled={loading} className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-bold shadow-lg shadow-orange-100 active:scale-95 transition-all">
                {loading ? 'VERIFICANDO...' : 'CONFIRMAR'}
              </button>
            </motion.form>
          )}

          {authStep === 'profile-setup' && (
            <motion.form 
              key="profile-setup"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleProfileSetup} 
              className="space-y-6"
            >
              <div className="text-center">
                <h2 className="text-xl font-bold text-[#001F3F]">Perfil</h2>
                <p className="text-sm text-gray-500">Adicione seu nome e uma foto de perfil.</p>
              </div>
              
              <div className="flex flex-col items-center gap-4">
                <div className="relative group">
                  <div className="w-32 h-32 rounded-full bg-gray-100 border-2 border-dashed border-[#EC6608] flex items-center justify-center overflow-hidden">
                    {profilePhoto ? (
                      <img src={profilePhoto} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                      <Camera size={40} className="text-[#EC6608]" />
                    )}
                  </div>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={handlePhotoUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>
                <p className="text-xs text-gray-400">Toque para alterar a foto</p>
              </div>

              <input
                type="text"
                placeholder="Seu nome"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="w-full px-4 py-4 bg-gray-50 border-b-2 border-[#EC6608] outline-none text-lg font-medium"
                required
              />
              
              {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
              <button disabled={loading} className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-bold shadow-lg shadow-orange-100 active:scale-95 transition-all">
                CONTINUAR
              </button>
            </motion.form>
          )}

          {authStep === 'permissions' && (
            <motion.div 
              key="permissions"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="text-center space-y-4">
                <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center mx-auto relative overflow-hidden">
                  <Camera size={40} className="text-[#EC6608] absolute opacity-20" />
                  <Mic size={40} className="text-[#EC6608]" />
                </div>
                <h2 className="text-2xl font-black text-[#001F3F]">Permissões do Sistema</h2>
                <p className="text-sm text-gray-500 leading-relaxed px-4">
                  Para que as chamadas e mensagens de voz funcionem, o SafeTalk precisa de autorização do sistema do seu celular.
                </p>
                <div className="bg-gray-50 p-4 rounded-xl text-left space-y-3">
                  <div className="flex items-center gap-3 text-sm text-gray-600 font-medium">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm text-[#EC6608]">1</div>
                    <span>Toque em "PERMITIR AGORA"</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-gray-600 font-medium">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm text-[#EC6608]">2</div>
                    <span>Autorize o acesso à Câmera e Microfone</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                {error && <p className="text-red-500 text-sm text-center font-bold bg-red-50 p-3 rounded-lg">{error}</p>}
                <button 
                  onClick={handleRequestPermissions}
                  disabled={loading}
                  className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-black text-lg shadow-lg shadow-orange-100 active:scale-95 transition-all uppercase tracking-wider"
                >
                  {loading ? 'SOLICITANDO...' : 'PERMITIR AGORA'}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );

  const AttachmentMenu = () => (
    <motion.div 
      initial={{ scale: 0, opacity: 0, y: 20 }}
      animate={{ scale: 1, opacity: 1, y: 0 }}
      exit={{ scale: 0, opacity: 0, y: 20 }}
      className="absolute bottom-20 left-4 right-4 bg-[#1f2c34] rounded-2xl p-6 grid grid-cols-3 gap-6 shadow-2xl z-50 border border-gray-800"
    >
      {[
        { icon: <FileText className="text-purple-400" />, label: 'Documento', type: 'file' },
        { icon: <Camera className="text-pink-400" />, label: 'Câmera', type: 'image' },
        { icon: <ImageIcon className="text-blue-400" />, label: 'Galeria', type: 'image' },
        { icon: <Mic className="text-orange-400" />, label: 'Áudio', type: 'audio' },
        { icon: <MapPin className="text-green-400" />, label: 'Localização', type: 'location' },
        { icon: <UserIcon className="text-blue-500" />, label: 'Contato', type: 'text' },
      ].map((item, i) => (
        <button 
          key={i}
          onClick={() => {
            if (item.type === 'audio') {
              startRecording();
            } else if (item.type === 'text') {
              // Contact logic
            } else {
              handleSendMedia(item.type as any);
            }
            setIsAttachmentMenuOpen(false);
          }}
          className="flex flex-col items-center gap-2 active:scale-95 transition-transform"
        >
          <div className="w-14 h-14 rounded-full bg-[#121b22] flex items-center justify-center shadow-lg border border-gray-800">
            {item.icon}
          </div>
          <span className="text-[10px] font-medium text-gray-300">{item.label}</span>
        </button>
      ))}
    </motion.div>
  );

    const HomeView = () => {
      const filteredChats = chats.filter(chat => 
        chat.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        chat.lastMessage?.toLowerCase().includes(searchQuery.toLowerCase())
      );

      const displayChats = filteredChats;

    return (
      <div className="flex flex-col h-screen bg-[#121b22] relative text-white overflow-hidden">
        {/* Top Header */}
        <div className="bg-[#EC6608] p-4 flex justify-between items-center text-white shadow-md z-40">
          <h1 className="text-2xl font-bold tracking-tight">SafeTalk</h1>
          <div className="flex items-center gap-4 relative">
            <Search size={22} className="cursor-pointer opacity-80 hover:opacity-100 transition-all" />
            <MoreVertical 
              size={22} 
              onClick={() => setShowMainMenu(!showMainMenu)} 
              className="cursor-pointer opacity-80 hover:opacity-100 transition-all" 
            />
            
            <AnimatePresence>
              {showMainMenu && (
                <motion.div
                  initial={{ opacity: 0, y: -10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -10, scale: 0.95 }}
                  className="absolute right-0 top-10 w-56 bg-[#1f2c34] rounded-xl shadow-2xl border border-gray-800 py-2 z-[60]"
                >
                  <button 
                    onClick={() => { setShowMainMenu(false); setView('profile'); }}
                    className="w-full px-4 py-3 text-left hover:bg-[#121b22] transition-colors flex items-center gap-3"
                  >
                    <UserIcon size={18} className="text-gray-400" />
                    <span className="text-sm font-medium">Perfil</span>
                  </button>
                  <button 
                    onClick={() => { setShowMainMenu(false); setShowSettings(true); }}
                    className="w-full px-4 py-3 text-left hover:bg-[#121b22] transition-colors flex items-center gap-3 border-t border-gray-800"
                  >
                    <Settings size={18} className="text-gray-400" />
                    <span className="text-sm font-medium">Configurações</span>
                  </button>
                  <button 
                    onClick={() => { setShowMainMenu(false); setShowSecurityCard(true); }}
                    className="w-full px-4 py-3 text-left hover:bg-[#121b22] transition-colors flex items-center gap-3 border-t border-gray-800"
                  >
                    <Shield size={18} className="text-gray-400" />
                    <span className="text-sm font-medium">Cartão de Segurança</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto bg-[#121b22] no-scrollbar pb-20">
          {activeTab === 'chats' ? (
            <div className="">
              {displayChats.length > 0 ? displayChats.map(chat => {
                const hasStatus = statuses.some(s => s.userId === chat.id);
                return (
                  <div 
                    key={chat.id} 
                    onClick={() => { setActiveChat(chat as any); setView('chat'); }}
                    className="flex items-center gap-4 px-4 py-3 hover:bg-[#1f2c34] transition-all cursor-pointer group"
                  >
                    <div className="relative">
                      <div className={`p-0.5 rounded-full ${hasStatus ? 'border-2 border-[#25D366]' : ''} ${(chat.auraUntil > Date.now() || chat.isBusiness) ? 'shadow-[0_0_15px_#ff6600] border-[#ff6600] border-2 animate-pulse' : ''}`}>
                        <img src={chat.avatar || `https://picsum.photos/seed/${chat.id}/200`} className="w-14 h-14 rounded-full bg-gray-700 object-cover" />
                      </div>
                    </div>
                    <div className="flex-1 overflow-hidden border-b border-gray-800 pb-3">
                      <div className="flex justify-between items-center mb-0.5">
                        <div className="flex items-center gap-1">
                          <h3 className="font-bold truncate text-gray-100 text-base">{chat.name}</h3>
                          {(chat.auraUntil > Date.now() || chat.businessVerified) && (
                            <ShieldCheck size={14} className="text-[#ff6600] fill-[#ff6600]/20" />
                          )}
                        </div>
                        <span className="text-[11px] text-[#EC6608] font-medium">
                          {chat.timestamp?.toDate ? chat.timestamp.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '18:01'}
                        </span>
                      </div>
                        <div className="flex justify-between items-center">
                          <p className={`text-sm truncate flex-1 leading-tight ${chat.typing && Object.entries(chat.typing).some(([uid, typing]) => uid !== user?.uid && typing) ? 'text-[#25D366] font-bold italic' : 'text-gray-400'}`}>
                            {chat.typing && Object.entries(chat.typing).some(([uid, typing]) => uid !== user?.uid && typing) 
                              ? 'digitando...' 
                              : chat.lastMessage}
                          </p>
                          {chat.unreadCount && chat.unreadCount > 0 && (
                            <div className="bg-[#EC6608] text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center ml-2">
                              {chat.unreadCount}
                            </div>
                          )}
                        </div>
                    </div>
                  </div>
                );
              }) : (
                <div className="p-10 text-center text-gray-500">
                  <MessageSquare size={48} className="mx-auto mb-4 opacity-20" />
                  <p>Nenhuma conversa encontrada.</p>
                </div>
              )}
            </div>
          ) : activeTab === 'status' ? (
            <div className="flex flex-col h-full">
              <div className="p-4">
                <div className="flex items-center gap-4 p-2 hover:bg-[#1f2c34] rounded-xl cursor-pointer" onClick={() => { setStatusType('text'); setShowStatusModal(true); }}>
                  <div className="relative">
                    <div className={`p-0.5 rounded-full ${statuses.some(s => s.userId === user?.uid) ? 'border-2 border-[#EC6608]' : ''} ${user?.auraUntil > Date.now() ? 'shadow-[0_0_15px_#ff6600] border-[#ff6600] border-2 animate-pulse' : ''}`}>
                      <img src={user?.photoURL} className="w-14 h-14 rounded-full bg-gray-700 object-cover" />
                    </div>
                    <div className="absolute bottom-0 right-0 bg-[#EC6608] rounded-full p-1 text-white border-2 border-[#121b22]">
                      <Plus size={14} />
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-100">Meu Status</h3>
                    <p className="text-xs text-gray-500">Toque para atualizar seu status</p>
                  </div>
                </div>
              </div>
              
              <div className="px-4 py-2">
                <p className="text-xs font-bold text-gray-500 mb-4">Atualizações recentes</p>
                <div className="space-y-4">
                  {statuses.length > 0 ? statuses.map(status => (
                    <div 
                      key={status.id} 
                      onClick={() => setViewingStatus(status)}
                      className="flex items-center gap-4 p-2 hover:bg-[#1f2c34] transition-all cursor-pointer"
                    >
                    <div className={`w-14 h-14 rounded-full p-0.5 border-2 ${status.user?.auraUntil > Date.now() ? 'shadow-[0_0_15px_#ff6600] border-[#ff6600] animate-pulse' : 'border-[#25D366]'} overflow-hidden`}>
                      <img src={status.user?.photoURL || `https://picsum.photos/seed/${status.userId}/200`} className="w-full h-full rounded-full object-cover" />
                    </div>
                      <div className="flex-1 border-b border-gray-800 pb-4">
                        <div className="flex items-center gap-1">
                          <h3 className="font-bold text-gray-100">{status.user?.displayName || 'Usuário'}</h3>
                          {status.user?.auraUntil > Date.now() && (
                            <ShieldCheck size={14} className="text-[#ff6600] fill-[#ff6600]/20" />
                          )}
                        </div>
                        <p className="text-xs text-gray-500">
                          {status.createdAt?.toDate ? status.createdAt.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Agora'}
                        </p>
                      </div>
                    </div>
                  )) : (
                    <div className="p-10 text-center text-gray-500">
                      <p className="text-sm">Nenhuma atualização de status.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col h-full">
              {callHistory.length > 0 ? callHistory.map(call => {
                const isCaller = call.callerId === user?.uid;
                const otherPartyName = isCaller ? (call.recipientName || 'Contato') : (call.callerName || 'Desconhecido');
                const otherPartyAvatar = isCaller ? (call.recipientAvatar || `https://picsum.photos/seed/${call.recipientId}/200`) : (call.callerAvatar || `https://picsum.photos/seed/${call.callerId}/200`);
                
                return (
                  <div key={call.id} className="flex items-center gap-4 px-4 py-3 hover:bg-[#1f2c34] transition-all cursor-pointer">
                    <img src={otherPartyAvatar} className="w-14 h-14 rounded-full bg-gray-700 object-cover" />
                    <div className="flex-1 border-b border-gray-800 pb-3">
                      <h3 className="font-bold text-gray-100">{otherPartyName}</h3>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        {call.status === 'missed' ? (
                          <PhoneOff size={12} className="text-red-500" />
                        ) : isCaller ? (
                          <PhoneCall size={12} className="text-green-500" />
                        ) : (
                          <Phone size={12} className="text-[#EC6608]" />
                        )}
                        <span>
                          {call.timestamp?.toDate ? call.timestamp.toDate().toLocaleString([], { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : 'Agora'}
                          {call.duration && ` • ${call.duration}`}
                        </span>
                      </div>
                    </div>
                    {call.type === 'video' ? <Video size={22} className="text-[#EC6608]" /> : <Phone size={22} className="text-[#EC6608]" />}
                  </div>
                );
              }) : (
                <div className="p-10 text-center text-gray-500">
                  <Phone size={48} className="mx-auto mb-4 opacity-20" />
                  <p>Nenhuma chamada recente.</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom Navigation Tabs */}
        <div className="absolute bottom-0 left-0 right-0 bg-[#1f2c34] border-t border-gray-800 flex items-center justify-around py-3 z-50">
          <div 
            onClick={() => setActiveTab('chats')}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-all ${activeTab === 'chats' ? 'text-[#EC6608]' : 'text-gray-400'}`}
          >
            <div className={`p-1 px-4 rounded-full transition-all ${activeTab === 'chats' ? 'bg-[#EC6608]/20' : ''}`}>
              <MessageSquare size={24} />
            </div>
            <span className="text-[10px] font-bold uppercase">Conversas</span>
          </div>
          <div 
            onClick={() => setActiveTab('status')}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-all ${activeTab === 'status' ? 'text-[#EC6608]' : 'text-gray-400'}`}
          >
            <div className={`p-1 px-4 rounded-full transition-all ${activeTab === 'status' ? 'bg-[#EC6608]/20' : ''}`}>
              <CircleDashed size={24} />
            </div>
            <span className="text-[10px] font-bold uppercase">Status</span>
          </div>
          <div 
            onClick={() => setActiveTab('calls')}
            className={`flex flex-col items-center gap-1 cursor-pointer transition-all ${activeTab === 'calls' ? 'text-[#EC6608]' : 'text-gray-400'}`}
          >
            <div className={`p-1 px-4 rounded-full transition-all ${activeTab === 'calls' ? 'bg-[#EC6608]/20' : ''}`}>
              <Phone size={24} />
            </div>
            <span className="text-[10px] font-bold uppercase">Chamadas</span>
          </div>
        </div>

        {/* Floating Action Button */}
        <div className="absolute bottom-24 right-6 flex flex-col gap-4 z-50">
          {activeTab === 'chats' && (
            <>
              <motion.button 
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setShowGroupModal(true)}
                className="w-12 h-12 bg-[#001F3F] rounded-full flex items-center justify-center text-white shadow-xl"
                title="Novo Grupo"
              >
                <Users size={20} />
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsSearchingContact(true)}
                className="w-14 h-14 bg-[#EC6608] rounded-full flex items-center justify-center text-white shadow-2xl"
                title="Adicionar Contato"
              >
                <UserPlus size={24} />
              </motion.button>
            </>
          )}
          {activeTab === 'status' && (
            <motion.button 
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => {
                setStatusType('text');
                setShowStatusModal(true);
              }}
              className="w-14 h-14 bg-[#EC6608] rounded-full flex items-center justify-center text-white shadow-2xl"
            >
              <Plus size={24} />
            </motion.button>
          )}
        </div>

        {/* Billing Modal */}
        <AnimatePresence>
          {showBusinessPlans && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 overflow-y-auto">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-[#121b22] w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-gray-800"
            >
              <div className="bg-[#EC6608] p-6 text-white text-center relative">
                <button 
                  onClick={() => {
                    setShowBusinessPlans(false);
                    setSelectedPlanForDetails(null);
                  }}
                  className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded-full transition-colors"
                >
                  <X size={20} />
                </button>
                {selectedPlanForDetails && (
                  <button 
                    onClick={() => setSelectedPlanForDetails(null)}
                    className="absolute top-4 left-4 p-2 hover:bg-white/10 rounded-full transition-colors"
                  >
                    <ArrowLeft size={20} />
                  </button>
                )}
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bot size={32} />
                </div>
                <h2 className="text-2xl font-black uppercase tracking-tighter italic">SafeTalk Business</h2>
                <p className="text-xs font-bold opacity-90 mt-1">Transforme seu perfil em uma máquina de vendas</p>
              </div>

              <div className="p-6 overflow-y-auto max-h-[60vh] no-scrollbar">
                {!selectedPlanForDetails ? (
                  <div className="space-y-4">
                    {[
                      { 
                        id: 'basic', 
                        name: 'Plano Básico', 
                        price: '90,00', 
                        icon: '✅',
                        features: ['IA Essencial', 'Proteção de Dados'],
                        color: 'gray'
                      },
                      { 
                        id: 'premium', 
                        name: 'Plano Premium', 
                        price: '100,00', 
                        icon: '🔥',
                        features: ['IA Avançada', 'Suporte Prioritário'],
                        color: 'orange'
                      },
                      { 
                        id: 'vip', 
                        name: 'VIP Business', 
                        price: '150,00', 
                        icon: '💎',
                        features: ['IA 24 Horas Híbrida', 'Perfil Verificado', 'Localização & Vitrine'],
                        color: 'orange',
                        highlight: true
                      }
                    ].map((plan) => (
                      <div 
                        key={plan.id}
                        className={`p-4 rounded-2xl border-2 transition-all cursor-pointer ${plan.highlight ? 'border-[#EC6608] bg-[#EC6608]/5' : 'border-gray-800 hover:border-gray-700'}`}
                        onClick={() => setSelectedPlanForDetails(plan.id)}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex gap-3">
                            <span className="text-2xl">{plan.icon}</span>
                            <div>
                              <h3 className="font-black text-white uppercase italic leading-tight">{plan.name}</h3>
                              <div className="flex flex-wrap gap-2 mt-1">
                                {plan.features.map(f => (
                                  <span key={f} className="text-[8px] font-bold bg-gray-800 text-gray-400 px-2 py-0.5 rounded-full uppercase">{f}</span>
                                ))}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-[10px] font-bold text-gray-500 uppercase">Mensal</p>
                            <p className="text-lg font-black text-[#EC6608]">R$ {plan.price}</p>
                          </div>
                        </div>
                        <div className="w-full py-2 rounded-xl font-bold text-xs uppercase tracking-widest text-center bg-gray-800 text-white hover:bg-gray-700 transition-colors">
                          Ver Detalhes
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-6"
                  >
                    {(() => {
                      const details: any = {
                        vip: {
                          icon: '💎',
                          title: 'Plano VIP Business – O Topo do Mercado',
                          price: '150,00',
                          description: 'Para empresas que buscam autoridade máxima e tecnologia de ponta.',
                          benefits: [
                            { label: 'Selo de Perfil Verificado', desc: 'Destaque-se com o selo oficial de autenticidade e segurança.' },
                            { label: 'SafeTalk IA Híbrida 24h', desc: 'Nossa tecnologia mais avançada que combina os maiores motores de IA do mundo para vender, tirar dúvidas e fechar negócios por você.' },
                            { label: 'Vitrine de Produtos', desc: 'Libere o upload de fotos dos seus produtos diretamente no seu perfil.' },
                            { label: 'Localização Estratégica', desc: 'Insira o endereço oficial para que seus clientes te encontrem em um clique.' },
                            { label: 'BIOS Profissional', desc: 'Configure o nome da sua marca e uma descrição que vende.' },
                            { label: 'Controle Total', desc: 'Ative ou desative a IA nas configurações sempre que quiser atender pessoalmente.' }
                          ]
                        },
                        premium: {
                          icon: '🔥',
                          title: 'Plano Premium – Performance e Agilidade',
                          price: '100,00',
                          description: 'Ideal para negócios que precisam de resposta rápida e suporte prioritário.',
                          benefits: [
                            { label: 'SafeTalk IA Avançada', desc: 'Inteligência treinada para entender as necessidades dos seus clientes e responder com precisão.' },
                            { label: 'Suporte Prioritário', desc: 'Sua empresa tem prioridade total em nossa central de atendimento.' },
                            { label: 'Gestão de Perfil Completa', desc: 'Altere as informações da sua empresa e BIOS quando precisar.' },
                            { label: 'Segurança de Dados', desc: 'Criptografia de última geração em todas as transações e conversas.' }
                          ]
                        },
                        basic: {
                          icon: '✅',
                          title: 'Plano Básico – O Essencial Profissional',
                          price: '90,00',
                          description: 'A porta de entrada para quem quer sair do amadorismo.',
                          benefits: [
                            { label: 'SafeTalk IA Padrão', desc: 'Automação inteligente para garantir que nenhum cliente fique no vácuo.' },
                            { label: 'Proteção de Dados Business', desc: 'Segurança reforçada para o seu perfil empresarial.' },
                            { label: 'Suporte Técnico', desc: 'Nossa equipe disponível para te ajudar em horário comercial.' }
                          ]
                        }
                      };
                      const plan = details[selectedPlanForDetails];
                      if (!plan) return null;

                      return (
                        <>
                          <div className="text-center space-y-2">
                            <span className="text-4xl block mb-2">{plan.icon}</span>
                            <h3 className="text-xl font-black text-white uppercase italic leading-tight">{plan.title}</h3>
                            <p className="text-[#EC6608] font-black text-2xl">R$ {plan.price}/mês</p>
                            <p className="text-gray-400 text-sm leading-relaxed">{plan.description}</p>
                          </div>

                          <div className="space-y-4">
                            {plan.benefits.map((benefit: any, idx: number) => (
                              <div key={idx} className="flex gap-3 items-start bg-white/5 p-3 rounded-xl border border-white/5">
                                <div className="mt-1">
                                  <Check size={16} className="text-[#EC6608]" />
                                </div>
                                <div>
                                  <p className="text-sm font-bold text-gray-100">{benefit.label}</p>
                                  <p className="text-[11px] text-gray-400 leading-tight mt-0.5">{benefit.desc}</p>
                                </div>
                              </div>
                            ))}
                          </div>

                          <button 
                            onClick={() => handleCreatePix(plan.price, 'business', selectedPlanForDetails as any)}
                            className="w-full bg-[#EC6608] text-white py-4 rounded-2xl font-black shadow-lg active:scale-95 transition-all uppercase tracking-widest mt-4"
                          >
                            Assinar Agora
                          </button>
                        </>
                      );
                    })()}
                  </motion.div>
                )}
              </div>

              <div className="p-4 bg-black/20 text-center">
                <p className="text-[10px] text-gray-500 font-medium">Pagamento seguro via EvoPay PIX</p>
              </div>
            </motion.div>
          </div>
        )}

        {showBillingModal && (
            <div className="fixed inset-0 bg-black/80 z-[200] flex items-center justify-center p-6 backdrop-blur-md">
              <motion.div 
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                className="bg-[#000000] rounded-3xl w-full max-w-sm overflow-hidden shadow-[0_0_40px_rgba(255,102,0,0.3)] border border-[#ff6600]/30"
              >
                <div className="bg-[#ff6600] p-6 text-[#000000] flex justify-between items-center shadow-[0_4px_20px_rgba(255,102,0,0.4)]">
                  <div className="flex items-center gap-2">
                    <SparklesIcon size={24} />
                    <h3 className="text-xl font-black uppercase italic">SafeTalk Business</h3>
                  </div>
                  <X size={24} onClick={() => { setShowBillingModal(false); setPixCode(null); setTransactionId(null); }} className="cursor-pointer" />
                </div>
                
                <div className="p-8 space-y-6">
                  {!pixCode ? (
                    <>
                      <div className="text-center space-y-2">
                        <p className="text-[#ff6600] text-xs font-bold uppercase tracking-widest">Plano Selecionado</p>
                        <div className="flex items-center justify-center gap-2">
                          <span className="text-2xl font-bold text-gray-400">R$</span>
                          <span className="text-4xl font-black text-white shadow-[0_4px_10px_rgba(255,102,0,0.2)]">{billingAmount}</span>
                        </div>
                        <p className="text-gray-400 text-xs mt-4">
                          Assinatura Mensal <span className="text-[#ff6600] font-bold">SafeTalk Business</span>
                        </p>
                      </div>

                      <div className="bg-[#121b22] p-4 rounded-2xl border border-gray-800">
                        <p className="text-[10px] text-gray-500 uppercase font-bold mb-2">Benefícios do Plano</p>
                        <ul className="text-xs space-y-2 text-gray-300">
                          <li className="flex items-center gap-2"><Check size={14} className="text-[#ff6600]" /> IA 24h Ativa</li>
                          <li className="flex items-center gap-2"><Check size={14} className="text-[#ff6600]" /> Perfil Verificado</li>
                          <li className="flex items-center gap-2"><Check size={14} className="text-[#ff6600]" /> Vitrine de Produtos</li>
                        </ul>
                      </div>

                      <button 
                        onClick={handleCreatePix}
                        disabled={isCheckingPayment || !billingAmount}
                        className="w-full bg-[#ff6600] text-[#000000] py-4 rounded-2xl font-black shadow-[0_0_25px_rgba(255,102,0,0.5)] active:scale-95 transition-all disabled:opacity-50 uppercase tracking-wider"
                      >
                        {isCheckingPayment ? 'GERANDO...' : 'GERAR PIX'}
                      </button>
                    </>
                  ) : (
                    <div className="space-y-6 text-center">
                      <div className="space-y-2">
                        <div className="w-16 h-16 bg-[#ff6600]/10 rounded-full flex items-center justify-center mx-auto animate-pulse border border-[#ff6600]/30 shadow-[0_0_15px_rgba(255,102,0,0.2)]">
                          <RotateCw size={32} className="text-[#ff6600] animate-spin" />
                        </div>
                        <h4 className="text-white font-bold">Aguardando Pagamento</h4>
                        <p className="text-xs text-gray-400">Pague o PIX para ativar seu SafeTalk Business instantaneamente.</p>
                      </div>

                      <div className="bg-[#121b22] p-4 rounded-2xl border border-[#ff6600]/30 space-y-3 shadow-[0_0_15px_rgba(255,102,0,0.1)]">
                        <p className="text-[10px] text-[#ff6600] font-bold uppercase">Código PIX (Copia e Cola)</p>
                        <div className="bg-black/40 p-3 rounded-xl break-all text-[10px] font-mono text-gray-300 border border-gray-800 max-h-24 overflow-y-auto">
                          {pixCode}
                        </div>
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(pixCode || '');
                            alert('Código PIX copiado!');
                          }}
                          className="w-full bg-white text-black py-3 rounded-xl font-black text-sm active:scale-95 transition-all uppercase shadow-lg"
                        >
                          Copiar Código PIX
                        </button>
                      </div>

                      {paymentStatus === 'COMPLETED' && (
                        <motion.div 
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="bg-green-500/20 text-green-400 p-4 rounded-2xl border border-green-500/50 flex items-center gap-3 shadow-[0_0_15px_rgba(34,197,94,0.2)]"
                        >
                          <Check size={24} />
                          <div className="text-left">
                            <p className="font-bold">Pagamento Confirmado!</p>
                            <p className="text-[10px]">Seu SafeTalk Business foi ativado com sucesso.</p>
                          </div>
                        </motion.div>
                      )}
                      
                      <p className="text-[9px] text-gray-500">O status é verificado automaticamente a cada 5 segundos.</p>
                    </div>
                  )}
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
        {isSearchingContact && (
          <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl"
            >
              <div className="bg-[#001F3F] p-6 text-white flex justify-between items-center">
                <h3 className="text-xl font-bold">Adicionar Contato</h3>
                <X size={24} onClick={() => setIsSearchingContact(false)} className="cursor-pointer" />
              </div>
              <form onSubmit={handleSearchAndAddContact} className="p-6 space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase">Número do Contato</label>
                  <input 
                    type="tel" 
                    placeholder="(00) 00000-0000"
                    value={searchPhone}
                    onChange={(e) => setSearchPhone(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border-b-2 border-[#EC6608] outline-none font-bold"
                    autoFocus
                  />
                  <p className="text-[10px] text-gray-400">Insira o número com DDD para encontrar seu amigo.</p>
                </div>
                {error && <p className="text-red-500 text-xs font-bold">{error}</p>}
                <button 
                  type="submit"
                  disabled={loading || !searchPhone.trim()}
                  className="w-full bg-[#EC6608] text-white py-4 rounded-2xl font-bold shadow-lg active:scale-95 transition-all disabled:opacity-50"
                >
                  {loading ? 'Buscando...' : 'ADICIONAR'}
                </button>
              </form>
            </motion.div>
          </div>
        )}

        {showSettings && (
          <div className="absolute inset-0 bg-white z-[60] flex flex-col">
            <div className="bg-[#001F3F] text-white p-4 flex items-center gap-4">
              <ArrowLeft size={24} onClick={() => setShowSettings(false)} className="cursor-pointer" />
              <h2 className="text-xl font-bold">Configurações</h2>
            </div>
            
            <div className="flex-1 overflow-y-auto bg-gray-50">
              <div className="bg-white p-4 flex items-center gap-4 border-b border-gray-100 mb-4">
                <div className="relative">
                  <img src={user?.photoURL} className="w-16 h-16 rounded-full border-2 border-[#EC6608] object-cover" />
                  <button 
                    onClick={() => setIsEditingProfile(true)}
                    className="absolute -bottom-1 -right-1 w-6 h-6 bg-[#EC6608] rounded-full flex items-center justify-center text-white border-2 border-white"
                  >
                    <Camera size={12} />
                  </button>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="text-xl font-bold">{user?.displayName}</h2>
                      <p className="text-sm text-gray-500">Disponível</p>
                    </div>
                    <button 
                      onClick={() => setIsEditingProfile(true)}
                      className="text-[#EC6608] text-xs font-bold uppercase"
                    >
                      Editar
                    </button>
                  </div>
                </div>
              </div>

              {isEditingProfile && (
                <motion.div 
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white p-4 border-b border-gray-100 mb-4 space-y-4"
                >
                  <h3 className="font-bold text-[#001F3F]">Editar Perfil</h3>
                  <div className="flex flex-col items-center gap-4">
                    <div className="relative">
                      <div className="w-24 h-24 rounded-full bg-gray-100 border-2 border-dashed border-[#EC6608] flex items-center justify-center overflow-hidden">
                        {profilePhoto ? (
                          <img src={profilePhoto} alt="Profile" className="w-full h-full object-cover" />
                        ) : (
                          <Camera size={30} className="text-[#EC6608]" />
                        )}
                      </div>
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handlePhotoUpload}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                      />
                    </div>
                  </div>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border-b-2 border-[#EC6608] outline-none font-medium"
                    placeholder="Seu nome"
                  />
                  <div className="flex gap-2">
                    <button 
                      onClick={() => setIsEditingProfile(false)}
                      className="flex-1 py-2 text-gray-500 font-bold"
                    >
                      Cancelar
                    </button>
                    <button 
                      onClick={handleUpdateProfile}
                      disabled={loading}
                      className="flex-1 py-2 bg-[#EC6608] text-white rounded-lg font-bold"
                    >
                      {loading ? 'Salvando...' : 'Salvar'}
                    </button>
                  </div>
                </motion.div>
              )}

              <div className="bg-white border-y border-gray-100 mb-4">
                <div className="p-4 border-b border-gray-50">
                  <h3 className="text-[#EC6608] font-bold text-sm uppercase mb-4">Notificações Push</h3>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-4">
                        <MessageSquare size={20} className="text-gray-400" />
                        <div>
                          <p className="font-medium">Mensagens</p>
                          <p className="text-xs text-gray-500">Notificar novas mensagens</p>
                        </div>
                      </div>
                      <div 
                        onClick={() => setMsgNotifications(!msgNotifications)}
                        className={`w-12 h-6 rounded-full transition-all relative cursor-pointer ${msgNotifications ? 'bg-[#EC6608]' : 'bg-gray-300'}`}
                      >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${msgNotifications ? 'right-1' : 'left-1'}`} />
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-4">
                        <Phone size={20} className="text-gray-400" />
                        <div>
                          <p className="font-medium">Chamadas</p>
                          <p className="text-xs text-gray-500">Notificar chamadas recebidas</p>
                        </div>
                      </div>
                      <div 
                        onClick={() => setCallNotifications(!callNotifications)}
                        className={`w-12 h-6 rounded-full transition-all relative cursor-pointer ${callNotifications ? 'bg-[#EC6608]' : 'bg-gray-300'}`}
                      >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${callNotifications ? 'right-1' : 'left-1'}`} />
                      </div>
                    </div>
                  </div>
                </div>

                {user?.isBusiness && (
                  <div className="p-4 border-b border-gray-50 bg-white">
                    <h3 className="text-[#EC6608] font-bold text-sm uppercase mb-4">SafeTalk Business</h3>
                    <div className="space-y-6">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-4">
                          <Bot size={20} className="text-gray-400" />
                          <div>
                            <p className="font-medium">IA 24 Horas</p>
                            <p className="text-xs text-gray-500">Atendimento automático ativado</p>
                          </div>
                        </div>
                        <div 
                          onClick={async () => {
                            const newState = !user.isAiEnabled;
                            await setDoc(doc(db, 'users', user.uid), { isAiEnabled: newState }, { merge: true });
                            setUser({ ...user, isAiEnabled: newState });
                          }}
                          className={`w-12 h-6 rounded-full transition-all relative cursor-pointer ${user.isAiEnabled ? 'bg-[#EC6608]' : 'bg-gray-300'}`}
                        >
                          <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${user.isAiEnabled ? 'right-1' : 'left-1'}`} />
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase">Nome da Empresa (BIOS)</label>
                          <input 
                            type="text"
                            value={user.businessBio || ''}
                            onChange={async (e) => {
                              const val = e.target.value;
                              setUser({ ...user, businessBio: val });
                              // Debounce this in real app
                            }}
                            onBlur={async () => {
                              await setDoc(doc(db, 'users', user.uid), { businessBio: user.businessBio }, { merge: true });
                            }}
                            className="w-full bg-gray-50 border-b border-gray-200 p-2 text-sm outline-none focus:border-[#EC6608]"
                            placeholder="Ex: Padaria do João"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase">Localização Oficial</label>
                          <div className="flex gap-2">
                            <input 
                              type="text"
                              value={user.businessLocation || ''}
                              onChange={(e) => setUser({ ...user, businessLocation: e.target.value })}
                              onBlur={async () => {
                                await setDoc(doc(db, 'users', user.uid), { businessLocation: user.businessLocation }, { merge: true });
                              }}
                              className="flex-1 bg-gray-50 border-b border-gray-200 p-2 text-sm outline-none focus:border-[#EC6608]"
                              placeholder="Endereço da empresa"
                            />
                            <MapPin size={20} className="text-[#EC6608] self-center" />
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase">Vitrine de Produtos (Galeria)</label>
                          <div className="grid grid-cols-3 gap-2 mt-2">
                            {user.businessPhotos?.map((url: string, idx: number) => (
                              <div key={idx} className="relative aspect-square rounded-lg overflow-hidden bg-gray-100 group">
                                <img src={url} className="w-full h-full object-cover" />
                                <button 
                                  onClick={async () => {
                                    const newPhotos = user.businessPhotos.filter((_: any, i: number) => i !== idx);
                                    await setDoc(doc(db, 'users', user.uid), { businessPhotos: newPhotos }, { merge: true });
                                    setUser({ ...user, businessPhotos: newPhotos });
                                  }}
                                  className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                >
                                  <X size={12} />
                                </button>
                              </div>
                            ))}
                            {(user.businessPhotos?.length || 0) < 6 && (
                              <label className="aspect-square rounded-lg border-2 border-dashed border-gray-200 flex flex-col items-center justify-center cursor-pointer hover:border-[#EC6608] hover:bg-orange-50 transition-all">
                                <Plus size={20} className="text-gray-400" />
                                <span className="text-[8px] text-gray-400 mt-1">Adicionar</span>
                                <input 
                                  type="file" 
                                  accept="image/*" 
                                  className="hidden" 
                                  onChange={async (e) => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      const storageRef = ref(storage, `business_photos/${user.uid}/${Date.now()}`);
                                      await uploadBytes(storageRef, file);
                                      const url = await getDownloadURL(storageRef);
                                      const newPhotos = [...(user.businessPhotos || []), url];
                                      await setDoc(doc(db, 'users', user.uid), { businessPhotos: newPhotos }, { merge: true });
                                      setUser({ ...user, businessPhotos: newPhotos });
                                    }
                                  }}
                                />
                              </label>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="p-4 border-b border-gray-50 bg-white">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-4">
                      {theme === 'dark' ? <Moon size={20} className="text-gray-400" /> : <Sun size={20} className="text-gray-400" />}
                      <div>
                        <p className="font-medium dark:text-wa-dark-text">Modo Escuro</p>
                        <p className="text-xs text-gray-500 dark:text-wa-dark-muted">Alternar entre tema claro e escuro</p>
                      </div>
                    </div>
                    <div 
                      onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
                      className={`w-12 h-6 rounded-full transition-all relative cursor-pointer ${theme === 'dark' ? 'bg-[#EC6608]' : 'bg-gray-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${theme === 'dark' ? 'right-1' : 'left-1'}`} />
                    </div>
                  </div>
                </div>
                
                <div className="p-4 border-b border-gray-50 bg-white dark:bg-wa-dark-surface">
                  <h3 className="text-[#EC6608] font-bold text-sm uppercase mb-4">Segurança</h3>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-4">
                      <ShieldCheck size={20} className="text-gray-400" />
                      <div>
                        <p className="font-medium dark:text-wa-dark-text">Bloqueio do App</p>
                        <p className="text-xs text-gray-500 dark:text-wa-dark-muted">
                          {isBiometricSupported ? 'Usar biometria ou senha do celular' : 'Não suportado neste dispositivo'}
                        </p>
                      </div>
                    </div>
                    <div 
                      onClick={toggleBiometric}
                      className={`w-12 h-6 rounded-full transition-all relative cursor-pointer ${isBiometricEnabled ? 'bg-[#EC6608]' : 'bg-gray-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${isBiometricEnabled ? 'right-1' : 'left-1'}`} />
                    </div>
                  </div>
                </div>

                {[
                  { icon: <Lock size={20} />, title: 'Privacidade', subtitle: 'Bloqueio, mensagens temporárias' },
                  { icon: <HelpCircle size={20} />, title: 'Ajuda', subtitle: 'Central de ajuda, fale conosco' },
                  { icon: <Info size={20} />, title: 'Dados e Armazenamento', subtitle: 'Uso de rede, download automático' },
                ].map((item, i) => (
                  <div key={i} className="flex items-center p-4 gap-4 hover:bg-gray-50 cursor-pointer border-b border-gray-50 last:border-0">
                    <div className="text-gray-400">{item.icon}</div>
                    <div>
                      <h3 className="font-medium">{item.title}</h3>
                      <p className="text-xs text-gray-500">{item.subtitle}</p>
                    </div>
                  </div>
                ))}

                {/* Logout option removed as per user request */}
                
                {!user?.isBusiness && (
                  <div 
                    onClick={() => { setShowSettings(false); setShowBusinessPlans(true); }}
                    className="flex items-center p-4 gap-4 hover:bg-gray-50 cursor-pointer border-t border-gray-50 mt-4 group"
                  >
                    <div className="w-10 h-10 bg-[#EC6608]/10 rounded-full flex items-center justify-center text-[#EC6608]">
                      <Bot size={20} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-[#EC6608] text-sm italic uppercase">SafeTalk Business</h3>
                      <p className="text-[10px] text-gray-500 font-bold">Mudar para conta profissional</p>
                    </div>
                    <ArrowRight size={16} className="text-gray-300 group-hover:text-[#EC6608] transition-colors" />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        
        <AnimatePresence>
          {showSecurityCard && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="fixed inset-0 bg-black/90 z-[150] flex items-center justify-center p-6 backdrop-blur-xl"
            >
              <div className="bg-gradient-to-br from-[#121b22] to-[#1f2c34] w-full max-w-sm rounded-[2.5rem] overflow-hidden shadow-[0_0_50px_rgba(236,102,8,0.2)] border border-white/10 relative">
                <div className="absolute top-4 right-4 z-10">
                  <X size={24} onClick={() => setShowSecurityCard(false)} className="text-white/50 cursor-pointer hover:text-white transition-colors" />
                </div>

                <div className="p-8 flex flex-col items-center text-center gap-6">
                  <div className="w-20 h-20 bg-[#EC6608] rounded-3xl flex items-center justify-center shadow-2xl shadow-orange-500/20">
                    <ShieldCheck size={40} className="text-white" />
                  </div>

                  <div className="space-y-2">
                    <h2 className="text-2xl font-black text-white tracking-tight uppercase italic">SafeTalk Card</h2>
                    <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">Identidade Digital Segura</p>
                  </div>

                  <div className="w-full bg-white p-4 rounded-3xl shadow-inner flex flex-col items-center gap-4">
                    <div className="w-48 h-48 bg-gray-100 rounded-2xl flex items-center justify-center border-4 border-gray-50">
                      <div className="grid grid-cols-4 gap-1 opacity-20">
                        {[...Array(16)].map((_, i) => (
                          <div key={i} className="w-8 h-8 bg-black rounded-sm" />
                        ))}
                      </div>
                    </div>
                    <div className="text-center">
                      <p className="text-black font-black text-lg uppercase tracking-tighter">{user?.displayName}</p>
                      <p className="text-gray-400 text-xs font-medium">{user?.phoneNumber}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 w-full">
                    <div className="bg-white/5 p-4 rounded-2xl border border-white/5 text-left">
                      <p className="text-[8px] text-white/40 uppercase font-bold mb-1">Status</p>
                      <p className="text-green-400 text-xs font-bold flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" /> Ativo
                      </p>
                    </div>
                    <div className="bg-white/5 p-4 rounded-2xl border border-white/5 text-left">
                      <p className="text-[8px] text-white/40 uppercase font-bold mb-1">Nível</p>
                      <p className="text-orange-400 text-xs font-bold uppercase italic">
                        {user?.isBusiness ? 'Business' : 'Padrão'}
                      </p>
                    </div>
                  </div>

                  <p className="text-[9px] text-white/20 font-medium max-w-[200px]">
                    Este cartão é sua prova de identidade no ecossistema SafeTalk. Mantenha-o seguro.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {activeTab === 'chats' && (
          <div className="fixed bottom-6 right-6 flex flex-col items-end gap-4 z-50">
            <AnimatePresence>
              {showFabMenu && (
                <motion.div 
                  initial={{ opacity: 0, y: 20, scale: 0.8 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 20, scale: 0.8 }}
                  className="flex flex-col items-end gap-3 mb-2"
                >
                  <button 
                    onClick={() => {
                      setShowFabMenu(false);
                      setShowGroupModal(true);
                    }}
                    className="flex items-center gap-3 bg-[#1f2c34] text-white px-4 py-3 rounded-2xl shadow-xl border border-gray-800 active:scale-95 transition-all"
                  >
                    <span className="text-sm font-bold">Criar Grupo</span>
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                      <Users size={20} />
                    </div>
                  </button>
                  <button 
                    onClick={async () => {
                      setShowFabMenu(false);
                      const num = prompt('Digite o número do contato:');
                      if (num) {
                        const cleanNum = num.replace(/\D/g, '');
                        if (cleanNum === user?.phoneNumber) {
                          alert('Você não pode adicionar a si mesmo.');
                          return;
                        }
                        const q = query(collection(db, 'users'), where('phoneNumber', '==', cleanNum));
                        const snapshot = await getDocs(q);
                        
                        if (!snapshot.empty) {
                          const targetUser = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
                          
                          // Add to user's contacts list in Firestore
                          const userRef = doc(db, 'users', user.uid);
                          const userDoc = await getDoc(userRef);
                          const currentContacts = userDoc.data()?.contacts || [];
                          
                          if (!currentContacts.includes(targetUser.id)) {
                            await setDoc(userRef, {
                              contacts: [...currentContacts, targetUser.id]
                            }, { merge: true });
                            
                            // Update local state
                            setUser({
                              ...user,
                              contacts: [...currentContacts, targetUser.id]
                            });
                          }

                          handleStartChatWithUser(targetUser);
                        } else {
                          alert('Usuário não encontrado no SafeTalk.');
                        }
                      }
                    }}
                    className="flex items-center gap-3 bg-[#1f2c34] text-white px-4 py-3 rounded-2xl shadow-xl border border-gray-800 active:scale-95 transition-all"
                  >
                    <span className="text-sm font-bold">Adicionar Contato</span>
                    <div className="w-10 h-10 bg-[#EC6608] rounded-full flex items-center justify-center">
                      <UserPlus size={20} />
                    </div>
                  </button>
                  <button 
                    onClick={() => {
                      setShowFabMenu(false);
                      handleViewContacts();
                    }}
                    className="flex items-center gap-3 bg-[#1f2c34] text-white px-4 py-3 rounded-2xl shadow-xl border border-gray-800 active:scale-95 transition-all"
                  >
                    <span className="text-sm font-bold">Ver Contatos</span>
                    <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                      <UserIcon size={20} />
                    </div>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
            
            <button 
              onClick={() => setShowFabMenu(!showFabMenu)}
              className={`w-16 h-16 bg-[#EC6608] rounded-full shadow-xl flex items-center justify-center text-white active:scale-90 transition-all z-50 ${showFabMenu ? 'rotate-45 bg-gray-600' : ''}`}
            >
              <Plus size={32} />
            </button>
          </div>
        )}

        {showContactsModal && (
          <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl flex flex-col max-h-[80vh]"
            >
              <div className="bg-[#001F3F] p-6 text-white flex justify-between items-center">
                <h3 className="text-xl font-bold">Contatos</h3>
                <X size={24} onClick={() => setShowContactsModal(false)} className="cursor-pointer" />
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {allUsers.length > 0 ? allUsers.map(u => (
                  <div 
                    key={u.id} 
                    onClick={() => handleStartChatWithUser(u)}
                    className="flex items-center gap-4 p-3 hover:bg-gray-50 rounded-2xl transition-all cursor-pointer border border-transparent hover:border-gray-200"
                  >
                    <img src={u.photoURL || `https://picsum.photos/seed/${u.id}/200`} className="w-12 h-12 rounded-full bg-gray-200 object-cover" />
                    <div>
                      <p className="font-bold text-gray-800">{u.displayName || 'Contato'}</p>
                      <p className="text-xs text-gray-500">{u.phoneNumber}</p>
                    </div>
                  </div>
                )) : (
                  <div className="p-10 text-center text-gray-500">
                    <p>Nenhum contato encontrado.</p>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}

        {showGroupModal && (
          <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-6 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl"
            >
              <div className="bg-[#001F3F] p-6 text-white flex justify-between items-center">
                <h3 className="text-xl font-bold">Novo Grupo</h3>
                <X size={24} onClick={() => setShowGroupModal(false)} className="cursor-pointer" />
              </div>
              <div className="p-6 space-y-6">
                <div className="flex flex-col items-center gap-4">
                  <div className="w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center border-2 border-dashed border-[#EC6608] text-[#EC6608]">
                    <Camera size={32} />
                  </div>
                  <p className="text-xs text-gray-400 font-bold uppercase">Foto do Grupo</p>
                </div>
                <input 
                  type="text" 
                  placeholder="Nome do Grupo"
                  value={groupName}
                  onChange={(e) => setGroupName(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 border-b-2 border-[#EC6608] outline-none font-bold text-lg"
                />
                <div className="space-y-2">
                  <p className="text-xs font-bold text-gray-400 uppercase">Adicionar Participantes</p>
                  <div className="flex gap-2 overflow-x-auto py-2">
                    {chats.map(c => (
                      <div 
                        key={c.id}
                        onClick={() => {
                          if (groupParticipants.includes(c.id)) {
                            setGroupParticipants(groupParticipants.filter(id => id !== c.id));
                          } else {
                            setGroupParticipants([...groupParticipants, c.id]);
                          }
                        }}
                        className={`flex-shrink-0 w-12 h-12 rounded-full border-2 transition-all cursor-pointer overflow-hidden ${groupParticipants.includes(c.id) ? 'border-[#EC6608] scale-110' : 'border-transparent opacity-60'}`}
                      >
                        <img src={c.avatar} className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>
                <button 
                  onClick={handleCreateGroup}
                  className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-bold shadow-lg shadow-orange-100 active:scale-95 transition-all"
                >
                  CRIAR GRUPO
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    );
  };

  const ChatRoomView = () => (
    <div className="flex flex-col h-screen bg-[#121b22]">
      <div className="bg-[#EC6608] text-white p-3 flex items-center gap-2 shadow-md z-50">
        <ArrowLeft size={24} onClick={() => setView('home')} className="cursor-pointer" />
        <img 
          src={activeChat?.avatar || `https://picsum.photos/seed/${activeChat?.id}/200`} 
          className="w-10 h-10 rounded-full bg-gray-200 cursor-pointer object-cover" 
          onClick={() => setShowContactProfile(true)}
        />
        <div className="flex-1 cursor-pointer" onClick={() => setShowContactProfile(true)}>
          <div className="flex items-center gap-1">
            <h3 className="font-bold leading-tight truncate max-w-[150px]">{activeChat?.name}</h3>
            {(activeChat?.auraUntil > Date.now() || activeChat?.businessVerified) && (
              <ShieldCheck size={14} className="text-[#ff6600] fill-[#ff6600]/20" />
            )}
          </div>
          <span className="text-[10px] opacity-90">
            {activeChat?.typing && Object.entries(activeChat.typing).some(([uid, typing]) => uid !== user?.uid && typing) 
              ? 'digitando...' 
              : (activeChat?.isBusiness && activeChat?.isAiEnabled ? 'IA 24h Ativa' : 'online')}
          </span>
        </div>
        <div className="flex gap-4 pr-1">
          <Phone 
            size={20} 
            className="cursor-pointer hover:text-white/80 transition-colors" 
            onClick={() => handleStartCall('voice')}
          />
          <Video 
            size={20} 
            className="cursor-pointer hover:text-white/80 transition-colors" 
            onClick={() => handleStartCall('video')}
          />
          <MoreVertical size={20} className="cursor-pointer" />
        </div>
      </div>

      <div 
        className="flex-1 overflow-y-auto p-4 space-y-2 bg-repeat opacity-90"
        style={{ 
          backgroundImage: activeChat?.themeBackground ? `url(${activeChat.themeBackground})` : `url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')`,
          backgroundSize: activeChat?.themeBackground ? 'cover' : 'auto',
          backgroundPosition: 'center'
        }}
      >
        {messages.map(msg => (
          <div 
            key={msg.id} 
            className={`max-w-[80%] p-2 rounded-lg whatsapp-shadow text-sm relative flex flex-col ${
              msg.senderId === user?.uid 
                ? 'bg-[#FFF3E0] dark:bg-wa-dark-sent self-end ml-auto rounded-tr-none' 
                : 'bg-white dark:bg-wa-dark-received self-start mr-auto rounded-tl-none'
            }`}
          >
            <div className="dark:text-wa-dark-text">
              {msg.type === 'image' && (
                <img src={msg.url} className="rounded-md mb-1 max-w-full h-auto" />
              )}
              {msg.type === 'video' && (
                <div className="relative rounded-md overflow-hidden bg-black aspect-video mb-1">
                  <video src={msg.url} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Play size={32} className="text-white opacity-80" />
                  </div>
                </div>
              )}
              {msg.text && (
                <div className="flex items-start gap-1">
                  {msg.isAi && <Bot size={14} className="text-[#EC6608] mt-1 shrink-0" />}
                  <p className="leading-relaxed pr-10">{msg.text}</p>
                </div>
              )}
            </div>
            {msg.type === 'location' && msg.locationData && (
              <div 
                onClick={() => window.open(`https://www.google.com/maps?q=${msg.locationData?.lat},${msg.locationData?.lng}`)}
                className="cursor-pointer"
              >
                <div className="bg-gray-100 dark:bg-wa-dark-bg rounded-md p-2 flex items-center gap-2 mb-1">
                  <MapPin size={20} className="text-[#EC6608]" />
                  <span className="text-xs font-bold text-blue-600 dark:text-blue-400">Ver localização</span>
                </div>
                <p className="text-[10px] text-gray-500 dark:text-wa-dark-muted truncate">{msg.locationData.address}</p>
              </div>
            )}
            {msg.type === 'audio' && (
              <div className="flex items-center gap-3 py-1 pr-2 min-w-[240px]">
                <div className="flex items-center gap-2 flex-1">
                  <button 
                    onClick={() => {
                      const audio = new Audio(msg.url);
                      audio.play();
                    }}
                    className="w-10 h-10 rounded-full bg-transparent flex items-center justify-center text-gray-500 hover:text-[#EC6608] transition-all"
                  >
                    <Play size={24} fill="currentColor" />
                  </button>
                  <div className="flex-1 flex flex-col gap-1">
                    <div className="relative h-8 flex items-center">
                       {/* Waveform placeholder */}
                       <div className="flex items-end gap-[2px] h-4">
                          {[...Array(20)].map((_, i) => (
                            <div key={i} className="w-[2px] bg-gray-300 rounded-full" style={{ height: `${Math.random() * 100}%` }} />
                          ))}
                       </div>
                       <div className="absolute left-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-blue-500 rounded-full border-2 border-white shadow-sm" />
                    </div>
                    <div className="flex justify-between text-[10px] text-gray-400">
                      <span>0:06</span>
                      <span>11:26</span>
                    </div>
                  </div>
                </div>
                <div className="relative">
                  <img 
                    src={msg.senderId === user?.uid ? (user?.photoURL || `https://picsum.photos/seed/${user?.uid}/200`) : (activeChat?.avatar || `https://picsum.photos/seed/${activeChat?.id}/200`)} 
                    className="w-12 h-12 rounded-full object-cover border border-gray-100" 
                  />
                  <div className="absolute -bottom-1 -left-1 bg-white rounded-full p-0.5 shadow-sm">
                    <Mic size={12} className="text-blue-500" />
                  </div>
                </div>
              </div>
            )}
            {msg.type === 'file' && (
              <div className="flex items-center gap-3 bg-gray-50 dark:bg-wa-dark-bg p-2 rounded-md mb-1 border border-gray-100 dark:border-gray-800">
                <div className="w-10 h-10 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center text-red-500">
                  <FileText size={20} />
                </div>
                <div className="flex-1 overflow-hidden">
                  <p className="text-xs font-bold truncate dark:text-wa-dark-text">{msg.fileName}</p>
                  <p className="text-[10px] text-gray-400">PDF • 1.2 MB</p>
                </div>
              </div>
            )}
            <div className="absolute bottom-1 right-2 flex items-center gap-1 text-[9px] text-gray-400 dark:text-wa-dark-muted">
              <span>
                {msg.timestamp?.toDate ? msg.timestamp.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '...'}
              </span>
              {msg.senderId === user?.uid && (
                <CheckCheck 
                  size={12} 
                  className={msg.isRead ? "text-blue-400" : "text-gray-400"} 
                />
              )}
            </div>
          </div>
        ))}
        <div ref={scrollRef} />
      </div>

      <AnimatePresence>
        {isAttachmentMenuOpen && <AttachmentMenu />}
      </AnimatePresence>

      <form onSubmit={handleSendMessage} className="p-2 flex flex-col gap-2 relative bg-gray-50 dark:bg-wa-dark-bg">
        <div className="flex items-center gap-2">
          <div className="flex-1 bg-white dark:bg-wa-dark-surface rounded-full px-4 py-2 flex items-center gap-3 whatsapp-shadow">
            <button 
              type="button" 
              onClick={() => setIsAttachmentMenuOpen(!isAttachmentMenuOpen)}
              className={`transition-colors ${isAttachmentMenuOpen ? 'text-[#EC6608]' : 'text-gray-400'}`}
            >
              <Paperclip size={20} />
            </button>
            {isRecording ? (
              <div className="flex-1 flex items-center gap-2 text-red-500 font-medium">
                <motion.div 
                  animate={{ opacity: [1, 0, 1] }}
                  transition={{ repeat: Infinity, duration: 1 }}
                  className="w-2 h-2 rounded-full bg-red-500"
                />
                <span>Gravando... {formatTime(recordingTime)}</span>
              </div>
            ) : (
              <input 
                type="text" 
                placeholder="Mensagem" 
                value={newMessage}
                onChange={(e) => {
                  const val = e.target.value;
                  setNewMessage(val);
                  
                  // Debounced typing status update
                  if (activeChat && user) {
                    const chatRef = doc(db, 'chats', activeChat.id);
                    const updateTyping = () => {
                      setDoc(chatRef, {
                        typing: { [user.uid]: val.length > 0 }
                      }, { merge: true }).catch(() => {});
                    };

                    // Simple debounce logic
                    if ((window as any).typingTimeout) clearTimeout((window as any).typingTimeout);
                    (window as any).typingTimeout = setTimeout(updateTyping, 500);
                  }
                }}
                className="flex-1 outline-none text-sm bg-transparent dark:text-wa-dark-text"
              />
            )}
          </div>
          {newMessage.trim() || isRecording ? (
            <button 
              type={isRecording ? 'button' : 'submit'}
              onClick={isRecording ? stopRecording : undefined}
              className="w-12 h-12 bg-[#EC6608] rounded-full flex items-center justify-center text-white shadow-md active:scale-90 transition-all"
            >
              {isRecording ? <Check size={24} /> : <Send size={20} className="ml-1" />}
            </button>
          ) : (
            <button 
              type="button"
              onMouseDown={startRecording}
              onMouseUp={stopRecording}
              onTouchStart={(e) => { e.preventDefault(); startRecording(); }}
              onTouchEnd={(e) => { e.preventDefault(); stopRecording(); }}
              className="w-12 h-12 bg-[#EC6608] rounded-full flex items-center justify-center text-white shadow-md active:scale-95 transition-all"
            >
              <Mic size={24} />
            </button>
          )}
        </div>
      </form>
    </div>
  );

  const ContactProfileView = () => {
    const [aiPrompt, setAiPrompt] = useState('');
    
    const generateAiBackground = async () => {
      if (!aiPrompt) return;
      setIsGeneratingTheme(true);
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
        const result = await ai.models.generateContent({
          model: "gemini-2.5-flash-image",
          contents: [{ parts: [{ text: `A beautiful, subtle, high-quality chat background wallpaper inspired by: ${aiPrompt}. Minimalist, dark or light depending on context, no text.` }] }]
        });
        
        for (const part of result.candidates[0].content.parts) {
          if (part.inlineData) {
            const imageUrl = `data:image/png;base64,${part.inlineData.data}`;
            if (activeChat) {
              await setDoc(doc(db, 'chats', activeChat.id), { themeBackground: imageUrl }, { merge: true });
              setActiveChat({ ...activeChat, themeBackground: imageUrl });
            }
            break;
          }
        }
      } catch (err) {
        console.error('Error generating AI background:', err);
      } finally {
        setIsGeneratingTheme(false);
      }
    };

    const handleBackgroundUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = async () => {
        const imageUrl = reader.result as string;
        if (activeChat) {
          await setDoc(doc(db, 'chats', activeChat.id), { themeBackground: imageUrl }, { merge: true });
          setActiveChat({ ...activeChat, themeBackground: imageUrl });
        }
      };
      reader.readAsDataURL(file);
    };

    return (
      <motion.div 
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        className="fixed inset-0 bg-[#121b22] z-[70] flex flex-col"
      >
        <div className="bg-[#EC6608] text-white p-4 flex items-center gap-4 shadow-lg">
          <ArrowLeft size={24} onClick={() => setShowContactProfile(false)} className="cursor-pointer" />
          <h2 className="text-xl font-bold">Dados do Contato</h2>
        </div>
        
        <div className="flex-1 overflow-y-auto bg-[#121b22]">
          <div className="bg-[#1f2c34] p-8 flex flex-col items-center gap-4 mb-4">
            <img src={activeChat?.avatar || `https://picsum.photos/seed/${activeChat?.id}/200`} className="w-32 h-32 rounded-full shadow-2xl object-cover border-4 border-[#EC6608]" />
            <div className="text-center">
              <h2 className="text-2xl font-bold text-white">{activeChat?.name}</h2>
              <p className="text-gray-400 text-sm">online</p>
            </div>
          </div>
          
          <div className="bg-[#1f2c34] p-4 mb-4">
            <h3 className="text-[#EC6608] font-bold text-sm uppercase mb-4 flex items-center gap-2">
              <Bell size={16} /> Notificações Personalizadas
            </h3>
            
            <div className="space-y-6">
              <div>
                <p className="text-[10px] text-gray-400 uppercase font-bold mb-2">Som da Notificação</p>
                <div className="grid grid-cols-2 gap-2">
                  {NOTIFICATION_SOUNDS.map(sound => (
                    <button
                      key={sound.id}
                      onClick={async () => {
                        if (activeChat) {
                          await setDoc(doc(db, 'chats', activeChat.id), { notificationSound: sound.id }, { merge: true });
                          setActiveChat({ ...activeChat, notificationSound: sound.id });
                          const audio = new Audio(sound.url);
                          audio.play().catch(e => console.error('Error playing sound:', e));
                        }
                      }}
                      className={`py-2 px-3 rounded-lg text-xs font-medium border transition-all ${
                        activeChat?.notificationSound === sound.id || (!activeChat?.notificationSound && sound.id === 'default')
                          ? 'bg-[#EC6608] border-[#EC6608] text-white'
                          : 'bg-[#233138] border-gray-700 text-gray-300 hover:border-gray-500'
                      }`}
                    >
                      {sound.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-[10px] text-gray-400 uppercase font-bold mb-2">Padrão de Vibração</p>
                <div className="grid grid-cols-2 gap-2">
                  {VIBRATION_PATTERNS.map(pattern => (
                    <button
                      key={pattern.id}
                      onClick={async () => {
                        if (activeChat) {
                          await setDoc(doc(db, 'chats', activeChat.id), { vibrationPattern: pattern.id }, { merge: true });
                          setActiveChat({ ...activeChat, vibrationPattern: pattern.id });
                          if (pattern.pattern.length > 0 && 'vibrate' in navigator) {
                            navigator.vibrate(pattern.pattern);
                          }
                        }
                      }}
                      className={`py-2 px-3 rounded-lg text-xs font-medium border transition-all ${
                        activeChat?.vibrationPattern === pattern.id || (!activeChat?.vibrationPattern && pattern.id === 'default')
                          ? 'bg-[#EC6608] border-[#EC6608] text-white'
                          : 'bg-[#233138] border-gray-700 text-gray-300 hover:border-gray-500'
                      }`}
                    >
                      {pattern.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#1f2c34] p-4 mb-4">
            <h3 className="text-[#EC6608] font-bold text-sm uppercase mb-4 flex items-center gap-2">
              <Palette size={16} /> Tema da Conversa
            </h3>
            
            <div className="space-y-4">
              <div className="relative">
                <button className="w-full py-3 border border-gray-700 rounded-xl flex items-center justify-center gap-2 text-sm font-medium text-white hover:bg-[#233138] transition-colors">
                  <ImageIcon size={18} className="text-[#EC6608]" /> Escolher da Galeria
                </button>
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={handleBackgroundUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </div>
              
              {activeChat?.themeBackground && (
                <div className="flex flex-col gap-2">
                  <p className="text-[10px] text-gray-400 uppercase font-bold">Preview do Fundo</p>
                  <div className="h-40 w-full rounded-lg overflow-hidden border border-gray-800">
                    <img src={activeChat.themeBackground} className="w-full h-full object-cover" />
                  </div>
                  <button 
                    onClick={async () => {
                      if (activeChat) {
                        await setDoc(doc(db, 'chats', activeChat.id), { themeBackground: null }, { merge: true });
                        setActiveChat({ ...activeChat, themeBackground: undefined });
                      }
                    }}
                    className="text-red-500 text-xs font-bold self-end py-2"
                  >
                    Remover Fundo
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    );
  };


  if (isAppLoading) {
    return (
      <div className="h-screen bg-white flex flex-col items-center justify-center relative">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex flex-col items-center gap-8"
        >
          {appLogo ? (
            <div className="w-40 h-40 flex items-center justify-center overflow-hidden">
              <img src={appLogo} alt="SafeTalk Logo" className="w-full h-full object-contain" />
            </div>
          ) : (
            <div className="w-24 h-24 bg-[#EC6608] rounded-[2rem] flex items-center justify-center shadow-2xl shadow-orange-500/20">
              <Shield size={48} className="text-white" />
            </div>
          )}
          
          {/* Orange Loading Spinner */}
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
            className="w-8 h-8 border-4 border-[#EC6608] border-t-transparent rounded-full"
          />
        </motion.div>

        {/* Bottom Text */}
        <div className="absolute bottom-12 flex flex-col items-center gap-2">
          <div className="flex items-center gap-2 text-[#EC6608] opacity-60">
            <Lock size={12} />
            <p className="text-[10px] font-bold uppercase tracking-[0.3em]">Criptografia de ponta</p>
          </div>
        </div>
      </div>
    );
  }

  if (isIncomingCall || callStatus !== 'idle') {
    return (
      <CallView 
        callStatus={callStatus}
        isIncomingCall={isIncomingCall}
        callType={callType}
        currentCallData={currentCallData}
        activeChat={activeChat}
        user={user}
        activeCallId={activeCallId}
        handleEndCall={handleEndCall}
        handleAcceptCall={handleAcceptCall}
        isCameraOn={isCameraOn}
        setIsCameraOn={setIsCameraOn}
        isMicOn={isMicOn}
        setIsMicOn={setIsMicOn}
        isSpeakerOn={isSpeakerOn}
        setIsSpeakerOn={setIsSpeakerOn}
        zegoContainerRef={zegoContainerRef}
        zegoJoinedRef={zegoJoinedRef}
        videoRef={videoRef}
        remoteVideoRef={remoteVideoRef}
      />
    );
  }
  
  if (!user) return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-md space-y-12">
        {/* Big Ball with Drawings (WhatsApp Style) */}
        <div className="flex flex-col items-center gap-4">
          <div className="text-center mb-2">
            <p className="text-[#EC6608] font-black text-xs uppercase tracking-[0.2em]">Novo aplicativo</p>
            <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest">Mais fácil de ser usado falar</p>
          </div>
          
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="w-48 h-48 rounded-full welcome-pattern flex items-center justify-center shadow-2xl relative overflow-hidden"
          >
            <ShieldCheck size={80} color="white" className="relative z-10 opacity-80" />
          </motion.div>
          
          <div className="text-center mt-4">
            <h1 className="text-4xl font-black text-[#EC6608] tracking-tight">SafeTalk</h1>
            <p className="text-gray-400 font-medium mt-1">Sua comunicação, protegida.</p>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {authStep === 'phone' && (
            <motion.form 
              key="phone"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleSendCode} 
              className="space-y-6"
            >
              <div className="text-center">
                <h2 className="text-xl font-bold text-[#001F3F]">Bem-vindo ao SafeTalk</h2>
                <p className="text-sm text-gray-500">Insira seu número de telefone para começar.</p>
              </div>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-[#EC6608]">+55</span>
                <input
                  type="tel"
                  placeholder="(00) 00000-0000"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full pl-16 pr-4 py-4 bg-gray-50 border-b-2 border-[#EC6608] outline-none text-lg font-bold"
                  required
                />
              </div>
              {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
              <button disabled={loading} className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-bold shadow-lg shadow-orange-100 active:scale-95 transition-all">
                {loading ? 'PROCESSANDO...' : 'AVANÇAR'}
              </button>
            </motion.form>
          )}

          {authStep === 'email' && (
            <motion.form 
              key="email"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleSendEmailCode} 
              className="space-y-6"
            >
              <div className="text-center">
                <h2 className="text-xl font-bold text-[#001F3F]">Quase lá! Agora seu e-mail</h2>
                <p className="text-sm text-gray-500">Enviaremos um código de segurança para seu e-mail.</p>
              </div>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#EC6608]" size={20} />
                <input
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-gray-50 border-b-2 border-[#EC6608] outline-none text-lg font-medium"
                  required
                />
              </div>
              {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
              <button disabled={loading} className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-bold shadow-lg shadow-orange-100 active:scale-95 transition-all">
                {loading ? 'ENVIANDO...' : 'CONTINUAR'}
              </button>
            </motion.form>
          )}

          {authStep === 'email-verify' && (
            <motion.form 
              key="email-verify"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleVerifyEmailCode} 
              className="space-y-6"
            >
              <div className="text-center">
                <h2 className="text-xl font-bold text-[#001F3F]">Código do E-mail</h2>
                <p className="text-sm text-gray-500">Insira o código enviado para {email}</p>
              </div>
              <input
                type="text"
                placeholder="123456"
                value={emailCode}
                onChange={(e) => setEmailCode(e.target.value)}
                className="w-full px-4 py-4 bg-gray-50 border-b-2 border-[#EC6608] outline-none text-center text-3xl tracking-[0.5em] font-black"
                maxLength={6}
                required
              />
              {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
              <button disabled={loading} className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-bold shadow-lg shadow-orange-100 active:scale-95 transition-all">
                {loading ? 'VERIFICANDO...' : 'CONFIRMAR'}
              </button>
            </motion.form>
          )}

          {authStep === 'profile-setup' && (
            <motion.form 
              key="profile-setup"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleProfileSetup} 
              className="space-y-6"
            >
              <div className="text-center">
                <h2 className="text-xl font-bold text-[#001F3F]">Perfil</h2>
                <p className="text-sm text-gray-500">Adicione seu nome e uma foto de perfil.</p>
              </div>
              
              <div className="flex flex-col items-center gap-4">
                <div className="relative group">
                  <div className="w-32 h-32 rounded-full bg-gray-100 border-2 border-dashed border-[#EC6608] flex items-center justify-center overflow-hidden">
                    {profilePhoto ? (
                      <img src={profilePhoto} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                      <Camera size={40} className="text-[#EC6608]" />
                    )}
                  </div>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={handlePhotoUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>
                <p className="text-xs text-gray-400">Toque para alterar a foto</p>
              </div>

              <input
                type="text"
                placeholder="Seu nome"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="w-full px-4 py-4 bg-gray-50 border-b-2 border-[#EC6608] outline-none text-lg font-medium"
                required
              />
              
              {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
              <button disabled={loading} className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-bold shadow-lg shadow-orange-100 active:scale-95 transition-all">
                CONTINUAR
              </button>
            </motion.form>
          )}

          {authStep === 'permissions' && (
            <motion.div 
              key="permissions"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="text-center space-y-4">
                <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center mx-auto relative overflow-hidden">
                  <Camera size={40} className="text-[#EC6608] absolute opacity-20" />
                  <Mic size={40} className="text-[#EC6608]" />
                </div>
                <h2 className="text-2xl font-black text-[#001F3F]">Permissões do Sistema</h2>
                <p className="text-sm text-gray-500 leading-relaxed px-4">
                  Para que as chamadas e mensagens de voz funcionem, o SafeTalk precisa de autorização do sistema do seu celular.
                </p>
                <div className="bg-gray-50 p-4 rounded-xl text-left space-y-3">
                  <div className="flex items-center gap-3 text-sm text-gray-600 font-medium">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm text-[#EC6608]">1</div>
                    <span>Toque em "PERMITIR AGORA"</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-gray-600 font-medium">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm text-[#EC6608]">2</div>
                    <span>Autorize o acesso à Câmera e Microfone</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                {error && <p className="text-red-500 text-sm text-center font-bold bg-red-50 p-3 rounded-lg">{error}</p>}
                <button 
                  onClick={handleRequestPermissions}
                  disabled={loading}
                  className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-black text-lg shadow-lg shadow-orange-100 active:scale-95 transition-all uppercase tracking-wider"
                >
                  {loading ? 'SOLICITANDO...' : 'PERMITIR AGORA'}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );

  const StatusModal = () => (
    <div className="fixed inset-0 bg-black/80 z-[100] flex flex-col items-center justify-center p-6 backdrop-blur-md">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-[#1f2c34] rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl"
      >
        <div className="bg-[#EC6608] p-6 text-white flex justify-between items-center">
          <h3 className="text-xl font-bold">Novo Status</h3>
          <X size={24} onClick={() => setShowStatusModal(false)} className="cursor-pointer" />
        </div>
        
        <div className="p-6 space-y-6">
          <div className="flex justify-center gap-2">
            <button 
              onClick={() => setStatusType('text')}
              className={`px-4 py-2 rounded-full text-[10px] font-bold transition-all ${statusType === 'text' ? 'bg-[#EC6608] text-white' : 'bg-[#121b22] text-gray-400'}`}
            >
              TEXTO
            </button>
            <button 
              onClick={() => setStatusType('image')}
              className={`px-4 py-2 rounded-full text-[10px] font-bold transition-all ${statusType === 'image' ? 'bg-[#EC6608] text-white' : 'bg-[#121b22] text-gray-400'}`}
            >
              IMAGEM
            </button>
            <button 
              onClick={() => setStatusType('video')}
              className={`px-4 py-2 rounded-full text-[10px] font-bold transition-all ${statusType === 'video' ? 'bg-[#EC6608] text-white' : 'bg-[#121b22] text-gray-400'}`}
            >
              VÍDEO
            </button>
          </div>

          <div className="relative">
            {statusType === 'text' ? (
              <div className="space-y-4">
                <div 
                  className="w-full h-64 rounded-2xl flex items-center justify-center p-4 text-center"
                  style={{ backgroundColor: statusColor }}
                >
                  <textarea 
                    value={statusText}
                    onChange={(e) => setStatusText(e.target.value)}
                    placeholder="O que você está pensando?"
                    className="w-full bg-transparent text-white text-xl font-bold outline-none placeholder:text-white/50 resize-none text-center"
                  />
                </div>
                <div className="flex justify-center gap-2 overflow-x-auto py-2">
                  {['#EC6608', '#001F3F', '#4CAF50', '#2196F3', '#9C27B0', '#F44336'].map(color => (
                    <div 
                      key={color}
                      onClick={() => setStatusColor(color)}
                      className={`w-8 h-8 rounded-full cursor-pointer border-2 ${statusColor === color ? 'border-gray-900' : 'border-transparent'}`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="w-full h-64 rounded-2xl bg-[#121b22] border-2 border-dashed border-[#EC6608] flex items-center justify-center overflow-hidden relative">
                  {statusType === 'image' && statusImage ? (
                    <img src={statusImage} className={`w-full h-full object-cover ${statusFilter !== 'none' ? `filter ${statusFilter}` : ''}`} />
                  ) : statusType === 'video' && statusVideo ? (
                    <video src={statusVideo} className={`w-full h-full object-cover ${statusFilter !== 'none' ? `filter ${statusFilter}` : ''}`} controls={false} autoPlay muted loop />
                  ) : (
                    <div className="flex flex-col items-center gap-2 text-[#EC6608]">
                      {statusType === 'image' ? <Camera size={32} /> : <Video size={32} />}
                      <span className="text-xs font-bold uppercase tracking-wider">
                        {statusType === 'image' ? 'Escolher Foto' : 'Escolher Vídeo'}
                      </span>
                    </div>
                  )}
                  <input 
                    type="file" 
                    accept="image/*,video/*"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;

                      const isVideo = file.type.startsWith('video/');
                      const isImage = file.type.startsWith('image/');
                      
                      if (!isVideo && !isImage) {
                        setError('Por favor, selecione uma imagem ou vídeo.');
                        return;
                      }

                      // Update type based on file
                      const newType = isVideo ? 'video' : 'image';
                      setStatusType(newType);

                      const localUrl = URL.createObjectURL(file);
                      if (isVideo) {
                        setStatusVideo(localUrl);
                        setStatusImage(null);
                      } else {
                        setStatusImage(localUrl);
                        setStatusVideo(null);
                      }

                      setLoading(true);
                      setError('');
                      try {
                        if (!user) throw new Error('Usuário não autenticado');
                        console.log(`Uploading ${newType} to Firebase Storage...`);
                        const storageRef = ref(storage, `statuses/${user.uid}/${Date.now()}_${file.name}`);
                        await uploadBytes(storageRef, file);
                        const url = await getDownloadURL(storageRef);
                        console.log('Download URL obtained:', url);
                        if (isVideo) {
                          setStatusVideo(url);
                        } else {
                          setStatusImage(url);
                        }
                      } catch (err: any) {
                        console.error('Error uploading status media:', err);
                        setError(`Erro no upload: ${err.message || 'Verifique sua conexão'}`);
                        if (isVideo) setStatusVideo(null);
                        else setStatusImage(null);
                      } finally {
                        setLoading(false);
                      }
                    }}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>
              </div>
            )}

            {/* Side Options Trigger */}
            <div className="absolute top-2 right-2 flex flex-col gap-2">
              <button 
                onClick={() => setShowStatusOptions(!showStatusOptions)}
                className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white hover:bg-black/60 transition-all"
              >
                <MoreVertical size={20} />
              </button>
              
              <AnimatePresence>
                {showStatusOptions && (
                  <motion.div 
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="flex flex-col gap-2 bg-black/60 backdrop-blur-md p-2 rounded-2xl border border-white/10"
                  >
                    {(statusType === 'image' || statusType === 'video') && (
                      <div className="flex flex-col gap-2">
                        <p className="text-[8px] font-bold text-white/50 uppercase text-center">Filtros</p>
                        <div className="grid grid-cols-2 gap-1">
                          {['none', 'grayscale', 'sepia', 'blur-sm', 'brightness-125', 'contrast-125'].map(f => (
                            <button 
                              key={f}
                              onClick={() => setStatusFilter(f)}
                              className={`w-6 h-6 rounded-md border ${statusFilter === f ? 'border-[#EC6608] bg-[#EC6608]/20' : 'border-white/20'}`}
                              title={f}
                            />
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="h-[1px] bg-white/10 my-1" />
                    <button 
                      onClick={() => {
                        const link = prompt('Insira o link:');
                        if (link) setStatusLink(link);
                      }}
                      className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-all"
                    >
                      <LinkIcon size={14} />
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {statusLink && (
            <div className="flex items-center gap-2 bg-[#121b22] p-3 rounded-xl border border-[#EC6608]/30">
              <LinkIcon size={14} className="text-[#EC6608]" />
              <span className="text-[10px] text-gray-300 truncate flex-1">{statusLink}</span>
              <X size={14} onClick={() => setStatusLink('')} className="text-gray-500 cursor-pointer" />
            </div>
          )}

          <button 
            onClick={handlePostStatus}
            disabled={loading || (!statusText && !statusImage && !statusVideo)}
            className="w-full py-4 bg-[#EC6608] text-white rounded-xl font-bold shadow-lg active:scale-95 transition-all disabled:opacity-50"
          >
            {loading ? 'POSTANDO...' : 'POSTAR STATUS'}
          </button>
        </div>
      </motion.div>
    </div>
  );

  const StatusViewer = () => (
    <div className="fixed inset-0 bg-black z-[110] flex flex-col">
      {/* Progress Bars */}
      <div className="absolute top-0 left-0 right-0 p-4 z-20 flex flex-col gap-2">
        <div className="w-full h-1 bg-white/20 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: '100%' }}
            transition={{ duration: 5, ease: "linear" }}
            onAnimationComplete={() => setViewingStatus(null)}
            className="h-full bg-white"
          />
        </div>
        <div className="flex justify-between items-center text-white">
          <div className="flex items-center gap-3">
            <img src={viewingStatus.user?.photoURL} className="w-10 h-10 rounded-full border border-white/20" />
            <div>
              <h4 className="font-bold text-sm">{viewingStatus.user?.displayName}</h4>
              <p className="text-[10px] opacity-70">
                {viewingStatus.createdAt?.toDate ? viewingStatus.createdAt.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Agora'}
              </p>
            </div>
          </div>
          <X size={24} onClick={() => setViewingStatus(null)} className="cursor-pointer" />
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center relative">
        {viewingStatus.type === 'text' ? (
          <div 
            className="w-full h-full flex items-center justify-center p-10 text-center"
            style={{ backgroundColor: viewingStatus.backgroundColor }}
          >
            <h2 className="text-4xl font-bold text-white leading-tight drop-shadow-lg">{viewingStatus.content}</h2>
          </div>
        ) : viewingStatus.type === 'image' ? (
          <img src={viewingStatus.content} className={`w-full h-full object-cover ${viewingStatus.filter !== 'none' ? `filter ${viewingStatus.filter}` : ''}`} />
        ) : (
          <video 
            src={viewingStatus.content} 
            className={`w-full h-full object-cover ${viewingStatus.filter !== 'none' ? `filter ${viewingStatus.filter}` : ''}`} 
            autoPlay 
            muted={false} 
            loop 
          />
        )}

        {/* Link Overlay */}
        {viewingStatus.link && (
          <motion.a 
            href={viewingStatus.link}
            target="_blank"
            rel="noopener noreferrer"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="absolute bottom-12 left-1/2 -translate-x-1/2 bg-white/20 backdrop-blur-md px-6 py-3 rounded-full flex items-center gap-2 text-white border border-white/30 hover:bg-white/30 transition-all"
          >
            <LinkIcon size={16} />
            <span className="text-sm font-bold">Ver Link</span>
          </motion.a>
        )}
      </div>
    </div>
  );

  return (
    <>
      {isAppLocked && user && <LockScreen onUnlock={() => setIsAppLocked(false)} />}
      <Toaster position="top-center" />
      {view === 'home' ? (
        <HomeView 
          user={user}
          chats={chats}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          showMainMenu={showMainMenu}
          setShowMainMenu={setShowMainMenu}
          setView={setView}
          setActiveChat={setActiveChat}
          setShowSettings={setShowSettings}
          setShowSecurityCard={setShowSecurityCard}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          statuses={statuses}
          setViewingStatus={setViewingStatus}
          setStatusType={setStatusType}
          setShowStatusModal={setShowStatusModal}
          handleLogout={handleLogout}
          callHistory={callHistory}
          setShowGroupModal={setShowGroupModal}
          setIsSearchingContact={setIsSearchingContact}
        />
      ) : (
        <ChatRoomView 
          activeChat={activeChat}
          user={user}
          messages={messages}
          newMessage={newMessage}
          setNewMessage={setNewMessage}
          handleSendMessage={handleSendMessage}
          handleSendMedia={handleSendMedia}
          setView={setView}
          setShowContactProfile={setShowContactProfile}
          handleStartCall={handleStartCall}
          scrollRef={scrollRef}
          isAttachmentMenuOpen={isAttachmentMenuOpen}
          setIsAttachmentMenuOpen={setIsAttachmentMenuOpen}
          AttachmentMenu={AttachmentMenu}
          isRecording={isRecording}
          recordingTime={recordingTime}
          startRecording={startRecording}
          stopRecording={stopRecording}
        />
      )}
      
      {/* Welcome Message Toast */}
      <AnimatePresence>
        {welcomeMessage && (
          <motion.div 
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 20, opacity: 1 }}
            exit={{ y: -100, opacity: 0 }}
            className="fixed top-0 left-1/2 -translate-x-1/2 bg-white/10 backdrop-blur-xl px-6 py-3 rounded-full border border-white/20 shadow-2xl z-[200] flex items-center gap-3"
          >
            <div className="w-8 h-8 rounded-full bg-[#EC6608] flex items-center justify-center">
              <Sparkles className="text-white" size={16} />
            </div>
            <p className="text-white font-bold text-sm whitespace-nowrap">{welcomeMessage}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* PWA Install Banner */}
      <AnimatePresence>
        {showInstallBanner && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-20 left-4 right-4 bg-[#EC6608] p-4 rounded-2xl shadow-2xl z-[100] flex items-center justify-between border border-white/20 backdrop-blur-lg"
          >
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-2 rounded-xl">
                <Sparkles className="text-white" size={20} />
              </div>
              <div>
                <p className="text-white font-bold text-sm">Instalar SafeTalk</p>
                <p className="text-white/80 text-[10px] leading-tight">Acesse mais rápido da sua tela inicial</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => setShowInstallBanner(false)}
                className="px-3 py-1.5 text-white/70 text-xs font-bold uppercase tracking-wider"
              >
                Agora não
              </button>
              <button 
                onClick={handleInstallApp}
                className="bg-white text-[#EC6608] px-4 py-1.5 rounded-lg text-xs font-black shadow-sm active:scale-95 transition-all"
              >
                INSTALAR
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showContactProfile && <ContactProfileView />}
        {showStatusModal && <StatusModal />}
        {viewingStatus && <StatusViewer />}
      </AnimatePresence>
    </>
  );
}

const CallView = ({ 
  callStatus, 
  isIncomingCall, 
  callType, 
  currentCallData, 
  activeChat, 
  user, 
  activeCallId, 
  handleEndCall, 
  handleAcceptCall,
  isCameraOn,
  setIsCameraOn,
  isMicOn,
  setIsMicOn,
  isSpeakerOn,
  setIsSpeakerOn,
  videoRef,
  remoteVideoRef,
  isRemoteVideoLoading,
  handleFlipCamera
}: any) => {
  const [callDuration, setCallDuration] = useState(0);

  useEffect(() => {
    let interval: any;
    if (callStatus === 'connected') {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callStatus]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black z-[100] flex flex-col items-center justify-between text-white overflow-hidden"
    >
      {/* Remote Video (Background) */}
      <div className="absolute inset-0 z-0">
        <video 
          ref={remoteVideoRef}
          autoPlay 
          playsInline 
          className={`w-full h-full object-cover transition-opacity duration-700 ${isRemoteVideoLoading ? 'opacity-0' : 'opacity-100'}`}
        />
        
        {/* Black screen until video loads */}
        {isRemoteVideoLoading && callStatus === 'connected' && (
          <div className="absolute inset-0 bg-black flex items-center justify-center">
            <div className="flex flex-col items-center gap-4">
              <div className="w-16 h-16 border-4 border-[#EC6608] border-t-transparent rounded-full animate-spin" />
              <p className="text-white/60 font-bold uppercase tracking-widest text-xs">Conectando...</p>
            </div>
          </div>
        )}

        {/* Voice Call UI */}
        {callType === 'voice' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#075e54]">
            <div className="relative">
              <motion.div 
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="w-48 h-48 rounded-full bg-white/10 flex items-center justify-center"
              >
                <img 
                  src={isIncomingCall ? (currentCallData?.callerAvatar || 'https://picsum.photos/seed/user/200') : (activeChat?.avatar || 'https://picsum.photos/seed/user/200')} 
                  className="w-40 h-40 rounded-full border-4 border-white/20 shadow-2xl object-cover" 
                />
              </motion.div>
            </div>
          </div>
        )}

        {/* Local Video (Floating) */}
        {callType === 'video' && isCameraOn && (
          <motion.div 
            drag
            dragMomentum={false}
            className="absolute top-10 right-6 w-28 h-40 bg-gray-800 rounded-2xl overflow-hidden shadow-2xl border border-white/20 z-30 cursor-move"
          >
            <video 
              ref={videoRef} 
              autoPlay 
              muted 
              playsInline 
              className="w-full h-full object-cover scale-x-[-1]" 
            />
          </motion.div>
        )}
      </div>

      {/* Top Info */}
      <div className="relative z-20 w-full flex flex-col items-center pt-16 px-6">
        <div className="flex items-center gap-2 mb-6 bg-black/20 backdrop-blur-md px-3 py-1 rounded-full border border-white/5">
          <Lock size={10} className="text-green-400" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Criptografado</span>
        </div>
        
        <h2 className="text-3xl font-black mb-1 drop-shadow-lg">{isIncomingCall ? (currentCallData?.callerName || 'Desconhecido') : (activeChat?.name || 'Chamando...')}</h2>
        <p className="text-lg font-bold opacity-90 drop-shadow-lg text-white">
          {callStatus === 'ringing' ? (isIncomingCall ? `Chamada de ${callType === 'video' ? 'vídeo' : 'voz'}` : 'Chamando...') : formatTime(callDuration)}
        </p>
      </div>

      {/* Call Controls */}
      <div className="relative z-20 w-full flex flex-col items-center gap-10 pb-20 px-10">
        {callStatus === 'ringing' ? (
          <div className="w-full flex flex-col items-center gap-16">
            {isIncomingCall ? (
              <div className="w-full flex justify-around items-end">
                <div className="flex flex-col items-center gap-3">
                  <button 
                    onClick={handleEndCall} 
                    className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center shadow-xl active:scale-90 transition-all"
                  >
                    <PhoneOff size={28} className="text-white" />
                  </button>
                  <span className="text-[11px] font-bold opacity-70">RECUSAR</span>
                </div>
                
                <div className="flex flex-col items-center gap-3">
                  <button 
                    onClick={handleAcceptCall} 
                    className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center shadow-2xl active:scale-90 transition-all"
                  >
                    {callType === 'video' ? <Video size={36} className="text-white" /> : <Phone size={36} className="text-white" />}
                  </button>
                  <span className="text-[11px] font-bold uppercase tracking-widest">Atender</span>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-6">
                <button 
                  onClick={handleEndCall}
                  className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center shadow-xl active:scale-90 transition-all"
                >
                  <PhoneOff size={28} className="text-white" />
                </button>
                <span className="text-xs font-bold tracking-widest opacity-60 uppercase">Desligar</span>
              </div>
            )}
          </div>
        ) : (
          <div className="w-full flex justify-center gap-8">
            <button 
              onClick={() => setIsMicOn(!isMicOn)}
              className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${isMicOn ? 'bg-white/20' : 'bg-red-500'}`}
            >
              {isMicOn ? <Mic size={24} /> : <MicOff size={24} />}
            </button>

            <button 
              onClick={handleEndCall}
              className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center shadow-lg active:scale-90 transition-all"
            >
              <PhoneOff size={28} className="text-white" />
            </button>

            <button 
              onClick={handleFlipCamera}
              className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center"
            >
              <RefreshCw size={24} />
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
};

const HomeView = memo(({ 
  showMainMenu,
  setShowMainMenu, 
  setView, 
  setActiveChat, 
  setShowSettings, 
  setShowSecurityCard,
  activeTab,
  setActiveTab,
  statuses,
  setViewingStatus,
  setStatusType,
  setShowStatusModal,
  handleLogout,
  user,
  chats,
  searchQuery,
  setSearchQuery,
  callHistory,
  setShowGroupModal,
  setIsSearchingContact
}: any) => {
  const filteredChats = chats.filter((chat: any) => 
    chat.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    chat.lastMessage?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const displayChats = filteredChats;

  return (
    <div className="flex flex-col h-screen bg-[#121b22] relative text-white overflow-hidden">
      {/* Top Header */}
      <div className="bg-[#EC6608] p-4 flex justify-between items-center text-white shadow-md z-40">
        <h1 className="text-2xl font-bold tracking-tight">SafeTalk</h1>
        <div className="flex items-center gap-4 relative">
          <Search size={22} className="cursor-pointer opacity-80 hover:opacity-100 transition-all" />
          <MoreVertical 
            size={22} 
            onClick={() => setShowMainMenu(!showMainMenu)} 
            className="cursor-pointer opacity-80 hover:opacity-100 transition-all" 
          />
          
          <AnimatePresence>
            {showMainMenu && (
              <motion.div
                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                className="absolute right-0 top-10 w-56 bg-[#1f2c34] rounded-xl shadow-2xl border border-gray-800 py-2 z-[60]"
              >
                <button 
                  onClick={() => { setShowMainMenu(false); setView('profile'); }}
                  className="w-full px-4 py-3 text-left hover:bg-[#121b22] transition-colors flex items-center gap-3"
                >
                  <UserIcon size={18} className="text-gray-400" />
                  <span className="text-sm font-medium">Perfil</span>
                </button>
                <button 
                  onClick={() => { setShowMainMenu(false); setShowSettings(true); }}
                  className="w-full px-4 py-3 text-left hover:bg-[#121b22] transition-colors flex items-center gap-3 border-t border-gray-800"
                >
                  <Settings size={18} className="text-gray-400" />
                  <span className="text-sm font-medium">Configurações</span>
                </button>
                <button 
                  onClick={() => { setShowMainMenu(false); setShowSecurityCard(true); }}
                  className="w-full px-4 py-3 text-left hover:bg-[#121b22] transition-colors flex items-center gap-3 border-t border-gray-800"
                >
                  <Shield size={18} className="text-gray-400" />
                  <span className="text-sm font-medium">Cartão de Segurança</span>
                </button>
                <div className="h-[1px] bg-gray-800 my-1 mx-2" />
                <button 
                  onClick={() => { setShowMainMenu(false); handleLogout(); }}
                  className="w-full px-4 py-3 text-left hover:bg-[#121b22] transition-colors flex items-center gap-3 text-red-400"
                >
                  <LogOut size={18} />
                  <span className="text-sm font-medium">Sair</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto bg-[#121b22] no-scrollbar pb-20">
        {activeTab === 'chats' ? (
          <div className="">
            {displayChats.length > 0 ? displayChats.map((chat: any) => {
              const hasStatus = statuses.some((s: any) => s.userId === chat.id);
              return (
                <div 
                  key={chat.id} 
                  onClick={() => { setActiveChat(chat as any); setView('chat'); }}
                  className="flex items-center gap-4 px-4 py-3 hover:bg-[#1f2c34] transition-all cursor-pointer group"
                >
                  <div className="relative">
                    <div className={`p-0.5 rounded-full ${hasStatus ? 'border-2 border-[#25D366]' : ''} ${(chat.auraUntil > Date.now() || chat.isBusiness) ? 'shadow-[0_0_15px_#ff6600] border-[#ff6600] border-2 animate-pulse' : ''}`}>
                      <img src={chat.avatar || `https://picsum.photos/seed/${chat.id}/200`} className="w-14 h-14 rounded-full bg-gray-700 object-cover" />
                    </div>
                  </div>
                  <div className="flex-1 overflow-hidden border-b border-gray-800 pb-3">
                    <div className="flex justify-between items-center mb-0.5">
                      <div className="flex items-center gap-1">
                        <h3 className="font-bold truncate text-gray-100 text-base">{chat.name}</h3>
                        {(chat.auraUntil > Date.now() || chat.businessVerified) && (
                          <ShieldCheck size={14} className="text-[#ff6600] fill-[#ff6600]/20" />
                        )}
                      </div>
                      <span className="text-[11px] text-[#EC6608] font-medium">
                        {chat.timestamp?.toDate ? chat.timestamp.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '18:01'}
                      </span>
                    </div>
                      <div className="flex justify-between items-center">
                        <p className={`text-sm truncate flex-1 leading-tight ${chat.typing && Object.entries(chat.typing).some(([uid, typing]) => uid !== user?.uid && typing) ? 'text-[#25D366] font-bold italic' : 'text-gray-400'}`}>
                          {chat.typing && Object.entries(chat.typing).some(([uid, typing]) => uid !== user?.uid && typing) 
                            ? 'digitando...' 
                            : chat.lastMessage}
                        </p>
                        {chat.unreadCount && chat.unreadCount > 0 && (
                          <div className="bg-[#EC6608] text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center ml-2">
                            {chat.unreadCount}
                          </div>
                        )}
                      </div>
                  </div>
                </div>
              );
            }) : (
              <div className="p-10 text-center text-gray-500">
                <MessageSquare size={48} className="mx-auto mb-4 opacity-20" />
                <p>Nenhuma conversa encontrada.</p>
              </div>
            )}
          </div>
        ) : activeTab === 'status' ? (
          <div className="flex flex-col h-full">
            <div className="p-4">
              <div className="flex items-center gap-4 p-2 hover:bg-[#1f2c34] rounded-xl cursor-pointer" onClick={() => { setStatusType('text'); setShowStatusModal(true); }}>
                <div className="relative">
                  <div className={`p-0.5 rounded-full ${statuses.some((s: any) => s.userId === user?.uid) ? 'border-2 border-[#EC6608]' : ''} ${user?.auraUntil > Date.now() ? 'shadow-[0_0_15px_#ff6600] border-[#ff6600] border-2 animate-pulse' : ''}`}>
                    <img src={user?.photoURL} className="w-14 h-14 rounded-full bg-gray-700 object-cover" />
                  </div>
                  <div className="absolute bottom-0 right-0 bg-[#EC6608] rounded-full p-1 text-white border-2 border-[#121b22]">
                    <Plus size={14} />
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-gray-100">Meu Status</h3>
                  <p className="text-xs text-gray-500">Toque para atualizar seu status</p>
                </div>
              </div>
            </div>
            
            <div className="px-4 py-2">
              <p className="text-xs font-bold text-gray-500 mb-4">Atualizações recentes</p>
              <div className="space-y-4">
                {statuses.length > 0 ? statuses.map((status: any) => (
                  <div 
                    key={status.id} 
                    onClick={() => setViewingStatus(status)}
                    className="flex items-center gap-4 p-2 hover:bg-[#1f2c34] rounded-xl cursor-pointer"
                  >
                    <div className={`p-0.5 rounded-full border-2 border-[#EC6608]`}>
                      <img src={status.avatar} className="w-14 h-14 rounded-full bg-gray-700 object-cover" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-100">{status.name}</h3>
                      <p className="text-xs text-gray-500">Hoje às 14:30</p>
                    </div>
                  </div>
                )) : (
                  <div className="p-10 text-center text-gray-500 opacity-20">
                    <p>Nenhuma atualização de status.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col h-full">
            {callHistory.length > 0 ? callHistory.map((call: any) => {
              const isCaller = call.callerId === user?.uid;
              const otherPartyName = isCaller ? (call.recipientName || 'Contato') : (call.callerName || 'Desconhecido');
              const otherPartyAvatar = isCaller ? (call.recipientAvatar || `https://picsum.photos/seed/${call.recipientId}/200`) : (call.callerAvatar || `https://picsum.photos/seed/${call.callerId}/200`);
              
              return (
                <div key={call.id} className="flex items-center gap-4 px-4 py-3 hover:bg-[#1f2c34] transition-all cursor-pointer">
                  <img src={otherPartyAvatar} className="w-14 h-14 rounded-full bg-gray-700 object-cover" />
                  <div className="flex-1 border-b border-gray-800 pb-3">
                    <h3 className="font-bold text-gray-100">{otherPartyName}</h3>
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      {call.status === 'missed' ? (
                        <PhoneOff size={12} className="text-red-500" />
                      ) : isCaller ? (
                        <PhoneCall size={12} className="text-green-500" />
                      ) : (
                        <Phone size={12} className="text-[#EC6608]" />
                      )}
                      <span>
                        {call.timestamp?.toDate ? call.timestamp.toDate().toLocaleString([], { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : 'Agora'}
                        {call.duration && ` • ${call.duration}`}
                      </span>
                    </div>
                  </div>
                  {call.type === 'video' ? <Video size={22} className="text-[#EC6608]" /> : <Phone size={22} className="text-[#EC6608]" />}
                </div>
              );
            }) : (
              <div className="p-10 text-center text-gray-500">
                <Phone size={48} className="mx-auto mb-4 opacity-20" />
                <p>Nenhuma chamada recente.</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Navigation Tabs */}
      <div className="absolute bottom-0 left-0 right-0 bg-[#1f2c34] border-t border-gray-800 flex items-center justify-around py-3 z-50">
        <div 
          onClick={() => setActiveTab('chats')}
          className={`flex flex-col items-center gap-1 cursor-pointer transition-all ${activeTab === 'chats' ? 'text-[#EC6608]' : 'text-gray-400'}`}
        >
          <div className={`p-1 px-4 rounded-full transition-all ${activeTab === 'chats' ? 'bg-[#EC6608]/20' : ''}`}>
            <MessageSquare size={24} />
          </div>
          <span className="text-[10px] font-bold uppercase">Conversas</span>
        </div>
        <div 
          onClick={() => setActiveTab('status')}
          className={`flex flex-col items-center gap-1 cursor-pointer transition-all ${activeTab === 'status' ? 'text-[#EC6608]' : 'text-gray-400'}`}
        >
          <div className={`p-1 px-4 rounded-full transition-all ${activeTab === 'status' ? 'bg-[#EC6608]/20' : ''}`}>
            <CircleDashed size={24} />
          </div>
          <span className="text-[10px] font-bold uppercase">Status</span>
        </div>
        <div 
          onClick={() => setActiveTab('calls')}
          className={`flex flex-col items-center gap-1 cursor-pointer transition-all ${activeTab === 'calls' ? 'text-[#EC6608]' : 'text-gray-400'}`}
        >
          <div className={`p-1 px-4 rounded-full transition-all ${activeTab === 'calls' ? 'bg-[#EC6608]/20' : ''}`}>
            <Phone size={24} />
          </div>
          <span className="text-[10px] font-bold uppercase">Chamadas</span>
        </div>
      </div>

      {/* Floating Action Button */}
      <div className="absolute bottom-24 right-6 flex flex-col gap-4 z-50">
        {activeTab === 'chats' && (
          <>
            <motion.button 
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowGroupModal(true)}
              className="w-12 h-12 bg-[#001F3F] rounded-full flex items-center justify-center text-white shadow-xl"
              title="Novo Grupo"
            >
              <Users size={20} />
            </motion.button>
            <motion.button 
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsSearchingContact(true)}
              className="w-14 h-14 bg-[#EC6608] rounded-full flex items-center justify-center text-white shadow-2xl"
              title="Adicionar Contato"
            >
              <UserPlus size={24} />
            </motion.button>
          </>
        )}
        {activeTab === 'status' && (
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              setStatusType('text');
              setShowStatusModal(true);
            }}
            className="w-14 h-14 bg-[#EC6608] rounded-full flex items-center justify-center text-white shadow-2xl"
          >
            <Plus size={24} />
          </motion.button>
        )}
      </div>
    </div>
  );
});

  const AttachmentMenu = memo(({ startRecording, handleSendMedia, setIsAttachmentMenuOpen }: any) => (
    <motion.div 
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 100, opacity: 0 }}
      className="absolute bottom-20 left-4 right-4 bg-[#1f2c34] rounded-2xl p-4 grid grid-cols-3 gap-4 whatsapp-shadow z-[60] border border-gray-800"
    >
      {[
        { icon: <FileText className="text-purple-400" />, label: 'Documento', type: 'file' },
        { icon: <Camera className="text-pink-400" />, label: 'Câmera', type: 'image' },
        { icon: <ImageIcon className="text-blue-400" />, label: 'Galeria', type: 'image' },
        { icon: <Mic className="text-orange-400" />, label: 'Áudio', type: 'audio' },
        { icon: <MapPin className="text-green-400" />, label: 'Localização', type: 'location' },
        { icon: <UserIcon className="text-blue-500" />, label: 'Contato', type: 'text' },
      ].map((item, i) => (
        <button 
          key={i}
          onClick={() => {
            if (item.type === 'audio') {
              startRecording();
            } else if (item.type === 'text') {
              // Contact logic
            } else {
              handleSendMedia(item.type as any);
            }
            setIsAttachmentMenuOpen(false);
          }}
          className="flex flex-col items-center gap-2 active:scale-95 transition-transform"
        >
          <div className="w-14 h-14 rounded-full bg-[#121b22] flex items-center justify-center shadow-lg border border-gray-800">
            {item.icon}
          </div>
          <span className="text-[10px] font-medium text-gray-300">{item.label}</span>
        </button>
      ))}
    </motion.div>
  ));

  const ContactProfileView = memo(({ 
    activeChat, 
    setShowContactProfile, 
    handleStartCall, 
    isGeneratingTheme, 
    setIsGeneratingTheme, 
    db 
  }: any) => {
    const [aiPrompt, setAiPrompt] = useState('');
    
    const generateAiBackground = async () => {
      if (!aiPrompt) return;
      setIsGeneratingTheme(true);
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
        const result = await ai.models.generateContent({
          model: "gemini-2.5-flash-image",
          contents: [{ parts: [{ text: `A beautiful, subtle, high-quality chat background wallpaper inspired by: ${aiPrompt}. Minimalist, dark or light depending on context, no text.` }] }]
        });
        
        if (result.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data) {
          const base64Data = result.candidates[0].content.parts[0].inlineData.data;
          const imageUrl = `data:image/png;base64,${base64Data}`;
          
          await setDoc(doc(db, 'chats', activeChat!.id), {
            themeBackground: imageUrl
          }, { merge: true });
          
          toast.success('Plano de fundo gerado com sucesso!');
        }
      } catch (err) {
        console.error('Error generating AI theme:', err);
        toast.error('Erro ao gerar plano de fundo.');
      } finally {
        setIsGeneratingTheme(false);
        setAiPrompt('');
      }
    };

    return (
      <div className="flex flex-col h-screen bg-[#121b22] text-white">
        <div className="bg-[#EC6608] p-4 flex items-center gap-4">
          <ArrowLeft size={24} onClick={() => setShowContactProfile(false)} className="cursor-pointer" />
          <h2 className="text-xl font-bold">Dados do contato</h2>
        </div>
        
        <div className="flex-1 overflow-y-auto">
          <div className="bg-[#1f2c34] p-8 flex flex-col items-center gap-4">
            <img 
              src={activeChat?.avatar || `https://picsum.photos/seed/${activeChat?.id}/200`} 
              className="w-40 h-40 rounded-full object-cover shadow-2xl border-4 border-[#121b22]" 
            />
            <div className="text-center">
              <h2 className="text-2xl font-bold">{activeChat?.name}</h2>
              <p className="text-gray-400">{activeChat?.phone || '+55 (92) 99123-4567'}</p>
            </div>
            
            <div className="flex gap-8 mt-4">
              <div className="flex flex-col items-center gap-1 cursor-pointer hover:text-[#EC6608] transition-colors" onClick={() => { setShowContactProfile(false); handleStartCall('voice'); }}>
                <div className="p-3 bg-[#121b22] rounded-full"><Phone size={24} /></div>
                <span className="text-xs">Ligar</span>
              </div>
              <div className="flex flex-col items-center gap-1 cursor-pointer hover:text-[#EC6608] transition-colors" onClick={() => { setShowContactProfile(false); handleStartCall('video'); }}>
                <div className="p-3 bg-[#121b22] rounded-full"><Video size={24} /></div>
                <span className="text-xs">Vídeo</span>
              </div>
              <div className="flex flex-col items-center gap-1 cursor-pointer hover:text-[#EC6608] transition-colors">
                <div className="p-3 bg-[#121b22] rounded-full"><Search size={24} /></div>
                <span className="text-xs">Pesquisar</span>
              </div>
            </div>
          </div>
          
          <div className="mt-2 space-y-2">
            <div className="bg-[#1f2c34] p-4">
              <p className="text-sm text-gray-400 mb-1">Recado e número de telefone</p>
              <p className="font-medium">Disponível</p>
              <p className="text-xs text-gray-500 mt-1">20 de março de 2024</p>
            </div>
            
            <div className="bg-[#1f2c34] p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <ImageIcon size={20} className="text-gray-400" />
                  <span className="font-medium">Mídia, links e docs</span>
                </div>
                <div className="flex items-center gap-1 text-gray-400">
                  <span className="text-sm">245</span>
                  <ChevronRight size={20} />
                </div>
              </div>
              <div className="flex gap-2 overflow-x-auto no-scrollbar">
                {[1,2,3,4,5].map(i => (
                  <img key={i} src={`https://picsum.photos/seed/media${i}/100`} className="w-20 h-20 rounded-lg object-cover shrink-0" />
                ))}
              </div>
            </div>

            <div className="bg-[#1f2c34] p-4">
              <div className="flex items-center gap-3 mb-4">
                <Sparkles size={20} className="text-[#EC6608]" />
                <span className="font-medium">Personalizar Conversa (IA)</span>
              </div>
              <div className="space-y-3">
                <p className="text-xs text-gray-400">Descreva como você quer o fundo desta conversa e nossa IA gerará para você.</p>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    placeholder="Ex: Praia ao pôr do sol, estilo neon..." 
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    className="flex-1 bg-[#121b22] border border-gray-700 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#EC6608]"
                  />
                  <button 
                    onClick={generateAiBackground}
                    disabled={isGeneratingTheme || !aiPrompt}
                    className="bg-[#EC6608] text-white px-4 py-2 rounded-lg text-sm font-bold disabled:opacity-50"
                  >
                    {isGeneratingTheme ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : 'Gerar'}
                  </button>
                </div>
              </div>
            </div>
            
            <div className="bg-[#1f2c34] p-4 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Bell size={20} className="text-gray-400" />
                  <span>Silenciar notificações</span>
                </div>
                <div className="w-10 h-5 bg-gray-700 rounded-full relative">
                  <div className="absolute left-1 top-1 w-3 h-3 bg-gray-400 rounded-full" />
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Music size={20} className="text-gray-400" />
                <span>Toque personalizado</span>
              </div>
              <div className="flex items-center gap-3">
                <ImageIcon size={20} className="text-gray-400" />
                <span>Visibilidade de mídia</span>
              </div>
            </div>
            
            <div className="bg-[#1f2c34] p-4 space-y-6">
              <div className="flex items-center gap-3 text-red-500">
                <Ban size={20} />
                <span>Bloquear {activeChat?.name}</span>
              </div>
              <div className="flex items-center gap-3 text-red-500">
                <Trash2 size={20} />
                <span>Denunciar {activeChat?.name}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  });

  const ChatRoomView = memo(({ 
    activeChat, 
    user, 
    messages, 
    newMessage, 
    setNewMessage, 
    handleSendMessage, 
    handleSendMedia,
    setView, 
    setShowContactProfile, 
    handleStartCall, 
    scrollRef, 
    isAttachmentMenuOpen, 
    setIsAttachmentMenuOpen, 
    AttachmentMenu, 
    isRecording, 
    recordingTime, 
    startRecording, 
    stopRecording 
  }: any) => (
    <div className="flex flex-col h-screen bg-[#121b22]">
    <div className="bg-[#EC6608] text-white p-3 flex items-center gap-2 shadow-md z-50">
      <ArrowLeft size={24} onClick={() => setView('home')} className="cursor-pointer" />
      <img 
        src={activeChat?.avatar || `https://picsum.photos/seed/${activeChat?.id}/200`} 
        className="w-10 h-10 rounded-full bg-gray-200 cursor-pointer object-cover" 
        onClick={() => setShowContactProfile(true)}
      />
      <div className="flex-1 cursor-pointer" onClick={() => setShowContactProfile(true)}>
        <div className="flex items-center gap-1">
          <h3 className="font-bold leading-tight truncate max-w-[150px]">{activeChat?.name}</h3>
          {(activeChat?.auraUntil > Date.now() || activeChat?.businessVerified) && (
            <ShieldCheck size={14} className="text-[#ff6600] fill-[#ff6600]/20" />
          )}
        </div>
        <span className="text-[10px] opacity-90">
          {activeChat?.typing && Object.entries(activeChat.typing).some(([uid, typing]) => uid !== user?.uid && typing) 
            ? 'digitando...' 
            : (activeChat?.isBusiness && activeChat?.isAiEnabled ? 'IA 24h Ativa' : 'online')}
        </span>
      </div>
      <div className="flex gap-4 pr-1">
        <Phone 
          size={20} 
          className="cursor-pointer hover:text-white/80 transition-colors" 
          onClick={() => handleStartCall('voice')}
        />
        <Video 
          size={20} 
          className="cursor-pointer hover:text-white/80 transition-colors" 
          onClick={() => handleStartCall('video')}
        />
        <MoreVertical size={20} className="cursor-pointer" />
      </div>
    </div>

    <div 
      className="flex-1 overflow-y-auto p-4 space-y-2 bg-repeat opacity-90"
      style={{ 
        backgroundImage: activeChat?.themeBackground ? `url(${activeChat.themeBackground})` : `url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')`,
        backgroundSize: activeChat?.themeBackground ? 'cover' : 'auto',
        backgroundPosition: 'center'
      }}
    >
      {messages.map((msg: any) => (
        <div 
          key={msg.id} 
          className={`max-w-[80%] p-2 rounded-lg whatsapp-shadow text-sm relative flex flex-col ${
            msg.senderId === user?.uid 
              ? 'bg-[#FFF3E0] dark:bg-wa-dark-sent self-end ml-auto rounded-tr-none' 
              : 'bg-white dark:bg-wa-dark-received self-start mr-auto rounded-tl-none'
          }`}
        >
          <div className="dark:text-wa-dark-text">
            {msg.type === 'image' && (
              <img src={msg.url} className="rounded-md mb-1 max-w-full h-auto" />
            )}
            {msg.type === 'video' && (
              <div className="relative rounded-md overflow-hidden bg-black aspect-video mb-1">
                <video src={msg.url} className="w-full h-full object-cover" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Play size={32} className="text-white opacity-80" />
                </div>
              </div>
            )}
            {msg.text && (
              <div className="flex items-start gap-1">
                {msg.isAi && <Bot size={14} className="text-[#EC6608] mt-1 shrink-0" />}
                <p className="leading-relaxed pr-10">{msg.text}</p>
              </div>
            )}
          </div>
          {msg.type === 'location' && msg.locationData && (
            <div 
              onClick={() => window.open(`https://www.google.com/maps?q=${msg.locationData?.lat},${msg.locationData?.lng}`)}
              className="cursor-pointer"
            >
              <div className="bg-gray-100 dark:bg-wa-dark-bg rounded-md p-2 flex items-center gap-2 mb-1">
                <MapPin size={20} className="text-[#EC6608]" />
                <span className="text-xs font-bold text-blue-600 dark:text-blue-400">Ver localização</span>
              </div>
              <p className="text-[10px] text-gray-500 dark:text-wa-dark-muted truncate">{msg.locationData.address}</p>
            </div>
          )}
          {msg.type === 'audio' && (
            <div className="flex items-center gap-3 py-1 pr-2 min-w-[240px]">
              <div className="flex items-center gap-2 flex-1">
                <button 
                  onClick={() => {
                    const audio = new Audio(msg.url);
                    audio.play();
                  }}
                  className="w-10 h-10 rounded-full bg-transparent flex items-center justify-center text-gray-500 hover:text-[#EC6608] transition-all"
                >
                  <Play size={24} fill="currentColor" />
                </button>
                <div className="flex-1 flex flex-col gap-1">
                  <div className="relative h-8 flex items-center">
                      {/* Waveform placeholder */}
                      <div className="flex items-end gap-[2px] h-4">
                        {[...Array(20)].map((_, i) => {
                          // Deterministic height based on index to prevent flickering on re-render
                          const height = 30 + ((i * 13) % 70);
                          return (
                            <div key={i} className="w-[2px] bg-gray-300 rounded-full" style={{ height: `${height}%` }} />
                          );
                        })}
                      </div>
                     <div className="absolute left-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-blue-500 rounded-full border-2 border-white shadow-sm" />
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-400">
                    <span>0:06</span>
                    <span>11:26</span>
                  </div>
                </div>
              </div>
              <div className="relative">
                <img 
                  src={msg.senderId === user?.uid ? (user?.photoURL || `https://picsum.photos/seed/${user?.uid}/200`) : (activeChat?.avatar || `https://picsum.photos/seed/${activeChat?.id}/200`)} 
                  className="w-12 h-12 rounded-full object-cover border border-gray-100" 
                />
                <div className="absolute -bottom-1 -left-1 bg-white rounded-full p-0.5 shadow-sm">
                  <Mic size={12} className="text-blue-500" />
                </div>
              </div>
            </div>
          )}
          {msg.type === 'file' && (
            <div className="flex items-center gap-3 bg-gray-50 dark:bg-wa-dark-bg p-2 rounded-md mb-1 border border-gray-100 dark:border-gray-800">
              <div className="w-10 h-10 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center text-red-500">
                <FileText size={20} />
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="text-xs font-bold truncate dark:text-wa-dark-text">{msg.fileName}</p>
                <p className="text-[10px] text-gray-400">PDF • 1.2 MB</p>
              </div>
            </div>
          )}
          <div className="absolute bottom-1 right-2 flex items-center gap-1 text-[9px] text-gray-400 dark:text-wa-dark-muted">
            <span>
              {msg.timestamp?.toDate ? msg.timestamp.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '...'}
            </span>
            {msg.senderId === user?.uid && (
              <CheckCheck 
                size={12} 
                className={msg.isRead ? "text-blue-400" : "text-gray-400"} 
              />
            )}
          </div>
        </div>
      ))}
      <div ref={scrollRef} />
    </div>

    <AnimatePresence>
      {isAttachmentMenuOpen && (
        <AttachmentMenu 
          startRecording={startRecording} 
          handleSendMedia={handleSendMedia} 
          setIsAttachmentMenuOpen={setIsAttachmentMenuOpen} 
        />
      )}
    </AnimatePresence>

    <form onSubmit={handleSendMessage} className="p-2 flex flex-col gap-2 relative bg-gray-50 dark:bg-wa-dark-bg">
      <div className="flex items-center gap-2">
        <div className="flex-1 bg-white dark:bg-wa-dark-surface rounded-full px-4 py-2 flex items-center gap-3 whatsapp-shadow">
          <button 
            type="button" 
            onClick={() => setIsAttachmentMenuOpen(!isAttachmentMenuOpen)}
            className={`transition-colors ${isAttachmentMenuOpen ? 'text-[#EC6608]' : 'text-gray-400'}`}
          >
            <Paperclip size={20} />
          </button>
          {isRecording ? (
            <div className="flex-1 flex items-center gap-2 text-red-500 font-medium">
              <motion.div 
                animate={{ opacity: [1, 0, 1] }}
                transition={{ repeat: Infinity, duration: 1 }}
                className="w-2 h-2 rounded-full bg-red-500"
              />
              <span>Gravando... {formatTime(recordingTime)}</span>
            </div>
          ) : (
            <input 
              type="text" 
              placeholder="Mensagem" 
              value={newMessage}
              onChange={(e) => {
                const val = e.target.value;
                setNewMessage(val);
                
                // Debounced typing status
                if (activeChat && user) {
                  const chatRef = doc(db, 'chats', activeChat.id);
                  const updateTyping = () => {
                    setDoc(chatRef, {
                      typing: { [user.uid]: val.length > 0 }
                    }, { merge: true }).catch(() => {});
                  };

                  if ((window as any).typingTimeout) clearTimeout((window as any).typingTimeout);
                  (window as any).typingTimeout = setTimeout(updateTyping, 500);
                }
              }}
              className="flex-1 outline-none text-sm bg-transparent dark:text-wa-dark-text"
            />
          )}
        </div>
        {newMessage.trim() || isRecording ? (
          <button 
            type={isRecording ? 'button' : 'submit'}
            onClick={isRecording ? stopRecording : undefined}
            className="w-12 h-12 bg-[#EC6608] rounded-full flex items-center justify-center text-white shadow-md active:scale-90 transition-all"
          >
            {isRecording ? <Check size={24} /> : <Send size={20} className="ml-1" />}
          </button>
        ) : (
          <button 
            type="button"
            onMouseDown={startRecording}
            onMouseUp={stopRecording}
            onTouchStart={(e) => { e.preventDefault(); startRecording(); }}
            onTouchEnd={(e) => { e.preventDefault(); stopRecording(); }}
            className="w-12 h-12 bg-[#EC6608] rounded-full flex items-center justify-center text-white shadow-md active:scale-95 transition-all"
          >
            <Mic size={24} />
          </button>
        )}
      </div>
    </form>
  </div>
));
