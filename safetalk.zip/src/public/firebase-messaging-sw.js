importScripts('https://www.gstatic.com/firebasejs/9.0.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.0.0/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyAutuuEZAp4Bnnw-1oA45Y0U3H3cja_qF0",
  authDomain: "safetalk-brasil.firebaseapp.com",
  projectId: "safetalk-brasil",
  storageBucket: "safetalk-brasil.firebasestorage.app",
  messagingSenderId: "820913360509",
  appId: "1:820913360509:web:0735159c421e8c42fdab14",
  measurementId: "G-QGSZ2XDSCJ"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  
  const notificationTitle = payload.notification.title || 'Chamada SafeTalk';
  const notificationOptions = {
    body: payload.notification.body || 'Você tem uma nova chamada.',
    icon: '/logo.png', // Placeholder
    data: payload.data,
    actions: [
      { action: 'accept', title: 'Atender' },
      { action: 'decline', title: 'Recusar' }
    ]
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  if (event.action === 'accept') {
    clients.openWindow('/?call=incoming&action=accept');
  } else {
    clients.openWindow('/?call=incoming&action=decline');
  }
});
